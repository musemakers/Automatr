import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Layout from '../components/Layout.jsx';
import AnalyzingIndicator from '../components/AnalyzingIndicator.jsx';
import PreservationPreview from '../components/PreservationPreview.jsx';
import PreservationLightbox from '../components/PreservationLightbox.jsx';
import PreservationSummary from '../components/PreservationSummary.jsx';
import HeadlineEditor from '../components/HeadlineEditor.jsx';
import HeroEditor from '../components/HeroEditor.jsx';
import AdaptEditor from '../components/AdaptEditor.jsx';
import ConvertVideoEditor from '../components/ConvertVideoEditor.jsx';
import CustomFeatureRunner from '../components/CustomFeatureRunner.jsx';
import GenerateHome, { getActiveTask } from '../components/GenerateHome.jsx';
import { Card, CardHead, Field, Chip, Btn, ErrorText, AiErrorNotice, ModelPill, CostTag, CaptionOverlay } from '../components/ui.jsx';
import { useWorkflow } from '../context/WorkflowContext.jsx';
import { useLightbox } from '../context/LightboxContext.jsx';
import { brandAssetsApi, postsApi, stockPhotosApi, aiApi, customFeaturesApi } from '../api/resources.js';
import { apiErrorMessage, apiErrorInfo, resolveAssetUrl } from '../api/client.js';
import { previewCanvasClass, previewAspectRatio } from '../utils/mediumAspect.js';
import { getFormat, POST_FORMATS, isCarouselFormat, catalogPlatformOf } from '../constants/postFormats.js';
import SuggestLink from '../components/SuggestLink.jsx';
import FieldWithSuggest from '../components/FieldWithSuggest.jsx';
import SizePicker from '../components/flow/SizePicker.jsx';
import { useLeaveGuard } from '../components/LeaveGuard.jsx';
import '../styles/new-creative.css';

const PURPOSES = [
  'Product launch',
  'Promotion / Sale',
  'Engagement post',
  'Announcement',
  'Brand awareness',
  'Educational / How-to',
  'Behind-the-scenes',
  'Customer testimonial / UGC',
  'Event promotion',
  'Seasonal / Holiday',
  'Thought leadership',
  'Community / Culture',
  'Recruitment / Hiring',
  'Customer appreciation',
  'Feature highlight',
  'Statement / PR response'
];

// The entire brief, from the basics through to the final review, is one
// continuous step-by-step flow. Related decisions are grouped onto the
// same screen (e.g. mood + style + lighting all live under "Look & feel")
// rather than each single field getting its own step - keeps the guided
// feel without turning a 2-minute brief into 12 clicks.

const MAIN_STEPS = [
  { key: 'basics', label: 'Basics' },
  { key: 'brief', label: 'Brief & notes' },
  { key: 'look', label: 'Look & feel' },
  { key: 'message', label: 'Message & constraints' },
  { key: 'sources', label: 'Reference creatives' },
  { key: 'review', label: 'Review & generate' }
];

const MOOD_TAGS = ['Bold', 'Minimal', 'Luxurious', 'Playful', 'Editorial', 'Warm', 'Futuristic', 'Nostalgic', 'Energetic', 'Calm'];
const STYLE_REFERENCES = [
  'Studio product photography',
  'Editorial lifestyle',
  'Cinematic film still',
  'Bold graphic / typographic',
  'Flat lay top-down',
  'Architectural / geometric',
  'Hand-illustrated',
  '3D render'
];
const PEOPLE_COUNTS = ['One person', 'A couple / two people', 'A small group or family', 'A crowd'];
const PEOPLE_AGES = ['Children', 'Teens / young adults', 'Adults', 'Seniors'];
const PEOPLE_GENDERS = ['Only female', 'Only male'];
const PEOPLE_STYLES = ['Candid, natural moment', 'Posed portrait', 'At work / in action'];
const PEOPLE_ETHNICITIES = ['Indian', 'South Asian (other)', 'East Asian', 'Southeast Asian', 'Middle Eastern', 'Black / African', 'White / European', 'Latino / Hispanic', 'Mixed / diverse group'];
const DEFAULT_PEOPLE_ETHNICITY = 'Indian';
const LIGHTING_STYLES = ['Natural daylight', 'Golden hour', 'Studio softbox', 'Dramatic high-contrast', 'Neon / vibrant', 'Moody low-key'];
const COMPOSITION_STYLES = ['Rule-of-thirds hero shot', 'Centered minimal', 'Dynamic diagonal', 'Flat lay top-down', 'Negative-space led'];

// Temporarily hidden: the "Guarantee logo / QR / legal text exactly" upload block.
const SHOW_EXACT_ASSET_UPLOAD = false;

// Lets the person drag rectangles over the original creative to mark areas
// that must not be modified (QR code, registration number, logo...). Regions
// are stored as fractions (0-1) of the image so they stay correct at any
// display size. They end up in the image prompt - see regionsLine in
// buildTemplateInstruction (server designService.js).
function ProtectedRegionOverlay({ src, regions, onChange }) {
  const wrapRef = useRef(null);
  const [drag, setDrag] = useState(null); // { x0, y0, x1, y1 } in 0-1 coords while drawing

  const toFrac = (e) => {
    const rect = wrapRef.current.getBoundingClientRect();
    return {
      x: Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)),
      y: Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height))
    };
  };

  function handleDown(e) {
    if (regions.length >= 8) return;
    e.currentTarget.setPointerCapture?.(e.pointerId);
    const { x, y } = toFrac(e);
    setDrag({ x0: x, y0: y, x1: x, y1: y });
  }
  function handleMove(e) {
    if (!drag) return;
    const { x, y } = toFrac(e);
    setDrag((d) => ({ ...d, x1: x, y1: y }));
  }
  function handleUp() {
    if (!drag) return;
    const r = { x: Math.min(drag.x0, drag.x1), y: Math.min(drag.y0, drag.y1), w: Math.abs(drag.x1 - drag.x0), h: Math.abs(drag.y1 - drag.y0), label: '' };
    setDrag(null);
    if (r.w < 0.02 || r.h < 0.02) return; // ignore stray clicks
    onChange([...regions, r]);
  }

  const box = (r, key, extra = {}) => (
    <div
      key={key}
      style={{
        position: 'absolute',
        left: `${r.x * 100}%`,
        top: `${r.y * 100}%`,
        width: `${r.w * 100}%`,
        height: `${r.h * 100}%`,
        border: '2px solid #2E5EFF',
        background: 'rgba(46, 94, 255, 0.18)',
        boxSizing: 'border-box',
        pointerEvents: 'none',
        ...extra
      }}
    />
  );

  return (
    <>
      <div ref={wrapRef} style={{ position: 'relative', lineHeight: 0, touchAction: 'none' }}>
        <img src={src} alt="Creative to adapt" draggable={false} style={{ width: '100%', height: 'auto', display: 'block', borderRadius: 10, userSelect: 'none' }} />
        <div
          onPointerDown={handleDown}
          onPointerMove={handleMove}
          onPointerUp={handleUp}
          onPointerCancel={() => setDrag(null)}
          style={{ position: 'absolute', inset: 0, cursor: regions.length >= 8 ? 'default' : 'crosshair' }}
        />
        {regions.map((r, i) => (
          <React.Fragment key={i}>
            {box(r, `b${i}`)}
            <span
              style={{
                position: 'absolute',
                left: `${r.x * 100}%`,
                top: `${r.y * 100}%`,
                transform: 'translateY(-100%)',
                background: '#2E5EFF',
                color: '#fff',
                fontSize: 11,
                lineHeight: '16px',
                padding: '0 5px',
                borderRadius: '4px 4px 0 0',
                pointerEvents: 'none'
              }}
            >
              {i + 1}
            </span>
          </React.Fragment>
        ))}
        {drag && box({ x: Math.min(drag.x0, drag.x1), y: Math.min(drag.y0, drag.y1), w: Math.abs(drag.x1 - drag.x0), h: Math.abs(drag.y1 - drag.y0) }, 'drag', { borderStyle: 'dashed' })}
      </div>
      <div style={{ lineHeight: 1.4, marginTop: 10 }}>
        <p className="hint" style={{ marginBottom: 8 }}>
          {regions.length === 0
            ? 'Drag on the creative to draw a box around anything that must stay exactly as it is - a QR code, registration number, logo.'
            : 'Boxed areas are sent to the AI as "do not modify". Name them so it knows what they are.'}
        </p>
        {regions.map((r, i) => (
          <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
            <span style={{ width: 20, height: 20, borderRadius: 4, background: '#2E5EFF', color: '#fff', fontSize: 11, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>{i + 1}</span>
            <input
              type="text"
              maxLength={60}
              placeholder="What is this? e.g. QR code"
              value={r.label || ''}
              onChange={(e) => onChange(regions.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))}
            />
            <button type="button" className="link-btn" onClick={() => onChange(regions.filter((_, j) => j !== i))}>Remove</button>
          </div>
        ))}
        {regions.length >= 8 && <p className="hint">Maximum of 8 boxes.</p>}
      </div>
    </>
  );
}

export default function GenerateMedia() {
  const navigate = useNavigate();
  const location = useLocation();
  // Opening Generate Media from the sidebar always lands on the start screen (New Creative / Finish Up / Quick Fixes),
  // even if a task is in progress - that task is offered on the Finish Up card instead of being re-opened automatically.
  const [atHome, setAtHome] = useState(Boolean(location.state?.home));
  useEffect(() => {
    if (location.state?.home) setAtHome(true);
  }, [location.key]); // eslint-disable-line react-hooks/exhaustive-deps
  const { post, setPost, reset, briefDraft, setBriefDraft } = useWorkflow();
  const D = briefDraft || {}; // saved unsaved-brief state from the last visit to this page (see the snapshot below)
  const { open: openLightbox } = useLightbox();

  // The fork at the very top of the brief: a brand-new concept (full
  // explore -> refine -> modify -> publish path) vs adapting an existing,
  // already-approved creative (agency workflow - one direction, straight
  // to Publish once the image is ready). See Stepper.jsx for the matching
  // shortened path this drives.
  // null = not yet chosen - shows the standalone fork screen below instead
  // of the brief form. Once a post already has a saved creativeType (an
  // existing draft being revisited), that choice carries over and the
  // fork screen is skipped entirely.
  const [creativeType, setCreativeType] = useState(() => ('creativeType' in D ? D.creativeType : (post?.creativeType || null)));
  // null = not yet answered. Only asked in Adaptation - see the gate in
  // handleGenerate that blocks generation if this is true and nothing's
  // been staged as an exact element, so the answer can't just be given
  // and then silently ignored.
  const [hasComplianceElements, setHasComplianceElements] = useState(() => ('hasComplianceElements' in D ? D.hasComplianceElements : (null)));
  // AI detection of what's actually in the uploaded template (logo, key
  // visual, secondary text, compliance text, decorative graphics), and the
  // person's editable preserve/redesign choices derived from it. null =
  // no template uploaded yet / analysis not run. See stageTemplateFile and
  // buildTemplateInstruction (designService.js) for how this flows through.
  const [templateAnalysis, setTemplateAnalysis] = useState(() => ('templateAnalysis' in D ? D.templateAnalysis : (null)));
  const [analyzingTemplate, setAnalyzingTemplate] = useState(false);
  // Dotted selection outlines drawn on the template preview for each
  // preserved element. showOutlines is the master on/off; hoveredRegion is
  // the option the pointer is over (so it can be located even if unticked).
  const [showOutlines, setShowOutlines] = useState(true);
  const [hoveredRegion, setHoveredRegion] = useState(null);
  // Per-element box corrections the person made by dragging on the preview, keyed like templateAnalysis.elements.regions.
  const [regionBoxes, setRegionBoxes] = useState(() => ('regionBoxes' in D ? D.regionBoxes : ({})));
  // The preserve/redesign picker opens in a lightbox once the creative has been analysed.
  const [preserveModalOpen, setPreserveModalOpen] = useState(false);
  const [preserveTab, setPreserveTab] = useState('elements');
  const [preservation, setPreservation] = useState(() => ('preservation' in D ? D.preservation : {
    preserveLogo: true,
    preserveKeyVisual: true,
    preserveSecondaryText: true,
    preserveComplianceText: true,
    preserveDecorative: true,
      preserveBackground: true,
    layoutFlexible: false
  }));
  // The literal headline text detected in the uploaded template (see
  // stageTemplateFile) and the person's chosen replacement for it. Only
  // relevant for Creative Adaptation - New Creative writes headlines from
  // scratch per copy direction instead of varying an existing one.
  const [originalHeadline, setOriginalHeadline] = useState(() => ('originalHeadline' in D ? D.originalHeadline : ('')));
  const [headlineOptions, setHeadlineOptions] = useState(() => ('headlineOptions' in D ? D.headlineOptions : ([])));
  const [generatingHeadlines, setGeneratingHeadlines] = useState(false);
  const [headlineError, setHeadlineError] = useState('');
  const [selectedHeadline, setSelectedHeadline] = useState(() => ('selectedHeadline' in D ? D.selectedHeadline : ('')));
  const [customHeadline, setCustomHeadline] = useState(() => ('customHeadline' in D ? D.customHeadline : ('')));
  const [purpose, setPurpose] = useState(() => ('purpose' in D ? D.purpose : (post?.purpose || PURPOSES[0])));
  const [mediums, setMediums] = useState(() => ('mediums' in D ? D.mediums : (post?.mediums?.length ? post.mediums : [])));
  const [briefNote, setBriefNote] = useState(() => ('briefNote' in D ? D.briefNote : (post?.briefNote || '')));

  // Creative direction - the exhaustive set of controls for steering toward
  // a genuinely on-brief, high-production-value creative rather than a
  // generic one-line image prompt.
  const cb = post?.creativeBrief || {};
  const [moodTags, setMoodTags] = useState(() => ('moodTags' in D ? D.moodTags : (cb.moodTags || [])));
  const [styleReferences, setStyleReferences] = useState(() => ('styleReferences' in D ? D.styleReferences : (cb.styleReferences || [])));
  const [lightingStyle, setLightingStyle] = useState(() => ('lightingStyle' in D ? D.lightingStyle : (cb.lightingStyle || '')));
  const [compositionStyle, setCompositionStyle] = useState(() => ('compositionStyle' in D ? D.compositionStyle : (cb.compositionStyle || '')));
  const [primaryMessage, setPrimaryMessage] = useState(() => ('primaryMessage' in D ? D.primaryMessage : (cb.primaryMessage || '')));
  const [mustInclude, setMustInclude] = useState(() => ('mustInclude' in D ? D.mustInclude : (cb.mustInclude || '')));
  const [mustAvoid, setMustAvoid] = useState(() => ('mustAvoid' in D ? D.mustAvoid : (cb.mustAvoid || '')));
  // Quality tier is fixed at high-fidelity - no longer a user choice.
  const qualityTier = 'high';
  const [includeTypography, setIncludeTypography] = useState(() => ('includeTypography' in D ? D.includeTypography : (cb.includeTypography ?? true)));
  const [useBrandStyle, setUseBrandStyle] = useState(() => ('useBrandStyle' in D ? D.useBrandStyle : (cb.useBrandStyle || false)));
  const [followBrand, setFollowBrand] = useState(() => ('followBrand' in D ? D.followBrand : (cb.followBrand !== false))); // "Follow Brand's Design Language"
  const [peopleMode, setPeopleMode] = useState(() => ('peopleMode' in D ? D.peopleMode : (cb.peopleMode || 'auto'))); // auto | include | none
  const [peopleCount, setPeopleCount] = useState(() => ('peopleCount' in D ? D.peopleCount : (cb.peopleCount || '')));
  const [peopleAge, setPeopleAge] = useState(() => ('peopleAge' in D ? D.peopleAge : (cb.peopleAge || [])));
  const [peopleGender, setPeopleGender] = useState(() => ('peopleGender' in D ? D.peopleGender : (cb.peopleGender || ''))); // '' = no preference | 'Only female' | 'Only male'
  const [peopleStyle, setPeopleStyle] = useState(() => ('peopleStyle' in D ? D.peopleStyle : (cb.peopleStyle || '')));
  // Indian by default; only an explicit deselect (empty string) means "no preference".
  const [peopleEthnicity, setPeopleEthnicity] = useState(() => ('peopleEthnicity' in D ? D.peopleEthnicity : (cb.peopleEthnicity ?? DEFAULT_PEOPLE_ETHNICITY)));
  const [peopleNote, setPeopleNote] = useState(() => ('peopleNote' in D ? D.peopleNote : (cb.peopleNote || '')));
  const [slideCount, setSlideCount] = useState(() => ('slideCount' in D ? D.slideCount : (cb.slideCount || 5)));

  const [suggestingLook, setSuggestingLook] = useState(false);
  const [lookSuggestionError, setLookSuggestionError] = useState('');
  const [lookSuggestionRationale, setLookSuggestionRationale] = useState('');

  const [suggestingMessage, setSuggestingMessage] = useState(false);
  const [messageSuggestionError, setMessageSuggestionError] = useState('');
  const [messageSuggestionRationale, setMessageSuggestionRationale] = useState('');

  // Where the user is in the overall wizard.
  const [stepIndex, setStepIndex] = useState(() => ('stepIndex' in D ? D.stepIndex : (0)));

  // Reference creatives - staged locally (no post exists yet at brief time)
  // and uploaded right after the post is created, before navigating on.
  const [stagedReferences, setStagedReferences] = useState(() => ('stagedReferences' in D ? D.stagedReferences : ([]))); // [{file, mode, exact, previewUrl}]
  // Four-way choice: 'include' (AI adapts it into the scene), 'exact'
  // (AI never sees it - pasted onto the finished image unmodified),
  // 'style' (mood/palette reference only, not the literal subject), or
  // 'template' (this reference IS a finished creative - AI preserves its
  // logo/layout/branding and only adapts the copy/message).
  const [referenceMode, setReferenceMode] = useState(() => ('referenceMode' in D ? D.referenceMode : ('include')));
  const referenceFileInputRef = useRef(null);
  const templateFileInputRef = useRef(null);
  const exactElementFileInputRef = useRef(null);

  // Stock photo search (Pexels) - hidden entirely if the server has no
  // PEXELS_API_KEY configured, same graceful-degradation pattern used for
  // AI providers elsewhere in this app.
  const [stockConfigured, setStockConfigured] = useState(false);
  const [showStockSearch, setShowStockSearch] = useState(false);
  const [stockQuery, setStockQuery] = useState('');
  const [stockResults, setStockResults] = useState([]);
  const [stockSearching, setStockSearching] = useState(false);
  const [stockError, setStockError] = useState('');
  const [addingStockId, setAddingStockId] = useState(null);

  const [assets, setAssets] = useState([]);
  const [selectedAssets, setSelectedAssets] = useState(() => ('selectedAssets' in D ? D.selectedAssets : (new Set(post?.selectedAssets || []))));
  const [exactAssets, setExactAssets] = useState(() => ('exactAssets' in D ? D.exactAssets : (new Set(post?.exactAssetIds || []))));

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Navigating back to "Generate Media" (e.g. via the sidebar) re-uses
  // whatever post/brief was last active in WorkflowContext, so returning
  // users land on a pre-filled form rather than a blank one - useful for
  // resuming an interrupted brief, but confusing when the intent was to
  // start a brand new post. This lets them explicitly clear it instead of
  // the page silently deciding for them either way.
  const hadExistingPost = useRef(Boolean(post?._id) || Boolean(briefDraft));
  function startFresh() {
    reset();
    setCreativeType(null);
    setHasComplianceElements(null);
    setTemplateAnalysis(null);
    setAnalyzingTemplate(false);
    setPreservation({
      preserveLogo: true,
      preserveKeyVisual: true,
      preserveSecondaryText: true,
      preserveComplianceText: true,
      preserveDecorative: true,
      preserveBackground: true,
      layoutFlexible: false
    });
    setOriginalHeadline('');
    setHeadlineOptions([]);
    setGeneratingHeadlines(false);
    setHeadlineError('');
    setSelectedHeadline('');
    setCustomHeadline('');
    setPurpose(PURPOSES[0]);
    setMediums([]);
    setPendingPlatform('');
    setPendingFormatId('');
    setBriefNote('');
    setMoodTags([]);
    setStyleReferences([]);
    setLightingStyle('');
    setCompositionStyle('');
    setPrimaryMessage('');
    setMustInclude('');
    setMustAvoid('');
    setIncludeTypography(true);
    setUseBrandStyle(false);
    setPeopleMode('auto');
    setPeopleCount('');
    setPeopleAge([]);
    setPeopleGender('');
    setPeopleStyle('');
    setPeopleEthnicity(DEFAULT_PEOPLE_ETHNICITY);
    setPeopleNote('');
    setSlideCount(5);
    setStagedReferences([]);
    setReferenceMode('include');
    setSelectedAssets(new Set());
    setExactAssets(new Set());
    setError('');
    hadExistingPost.current = false;
  }

  // Switching into Adaptation nudges the reference-mode default toward
  // "template" (since that's almost always what an adaptation actually
  // needs), but only if nothing's staged yet - never silently changes a
  // choice the person already made for references they're mid-upload on.
  function handleSelectCreativeType(type) {
    setCreativeType(type);
    setHasComplianceElements(null);
    setTemplateAnalysis(null);
    setAnalyzingTemplate(false);
    setPreservation({
      preserveLogo: true,
      preserveKeyVisual: true,
      preserveSecondaryText: true,
      preserveComplianceText: true,
      preserveDecorative: true,
      preserveBackground: true,
      layoutFlexible: false
    });
    setOriginalHeadline('');
    setHeadlineOptions([]);
    setGeneratingHeadlines(false);
    setHeadlineError('');
    setSelectedHeadline('');
    setCustomHeadline('');
    // The two modes have different-length step lists (Adaptation skips
    // Generation Settings, Look & feel, Message & constraints, and
    // Reference Creatives) - always restart the wizard at 0 rather than
    // risk stepIndex landing on a different step than intended if someone
    // switches type mid-way via "Change".
    setStepIndex(0);
    if (type === 'adaptation') {
      if (referenceMode === 'include' && stagedReferences.length === 0) setReferenceMode('template');
      // Adaptation strictly follows the uploaded template - clear any
      // creative-direction fields filled in while previously on New
      // Creative, so nothing stale/conflicting leaks into the brief. Their
      // input steps are hidden in this mode, so there'd be no way to
      // notice or fix them otherwise.
      setMoodTags([]);
      setStyleReferences([]);
      setLightingStyle('');
      setCompositionStyle('');
      setPeopleMode('auto');
      setPrimaryMessage('');
      setMustInclude('');
      setMustAvoid('');
      setSelectedAssets(new Set());
      setExactAssets(new Set());
    }
  }

  useEffect(() => {
    brandAssetsApi.list().then(({ assets }) => setAssets(assets)).catch(() => setAssets([]));
  }, []);

  useEffect(() => {
    stockPhotosApi.status().then(({ configured }) => setStockConfigured(configured)).catch(() => setStockConfigured(false));
  }, []);

  const [costs, setCosts] = useState(null); // GET /ai/cost-estimates - see CostTag usages below
  useEffect(() => {
    aiApi.getCostEstimates().then(setCosts).catch(() => setCosts(null));
  }, []);

  // Custom features built in Admin -> Brief Studio and switched on for this workspace (one extra tile each).
  const [customFeatures, setCustomFeatures] = useState([]);
  useEffect(() => {
    customFeaturesApi.list().then(({ features }) => setCustomFeatures(features || [])).catch(() => setCustomFeatures([]));
  }, []);

  const ALL_PLATFORMS = [...new Set(POST_FORMATS.map((f) => f.platform))];
  // Nothing is chosen on a fresh brief: the size dropdown only appears once a platform is picked.
  const [pendingPlatform, setPendingPlatform] = useState(() => ('pendingPlatform' in D ? D.pendingPlatform : (mediums[0] ? catalogPlatformOf(mediums[0]) : '')));
  const [pendingFormatId, setPendingFormatId] = useState(() => ('pendingFormatId' in D ? D.pendingFormatId : (mediums[0] || '')));
  // Remember the whole unsaved brief when leaving this page, so coming back (sidebar, browser back, another step) restores it.
  const draftRef = useRef({});
  draftRef.current = { creativeType, hasComplianceElements, templateAnalysis, regionBoxes, preservation, originalHeadline, headlineOptions, selectedHeadline, customHeadline, purpose, mediums, briefNote, moodTags, styleReferences, lightingStyle, compositionStyle, primaryMessage, mustInclude, mustAvoid, qualityTier, includeTypography, useBrandStyle, followBrand, peopleMode, peopleCount, peopleAge, peopleGender, peopleStyle, peopleEthnicity, peopleNote, slideCount, stepIndex, stagedReferences, referenceMode, selectedAssets, exactAssets, pendingPlatform, pendingFormatId };
  const skipDraftSave = useRef(false); // set once the brief has been saved as a post - nothing left to restore
  useEffect(() => () => { if (!skipDraftSave.current) setBriefDraft(draftRef.current); }, [setBriefDraft]);

  // The shared size picker (platform first, then the sizes for it). Carousel and video placements are not in that list,
  // so they stay available through the "Carousel or video format" select below it.
  function handleSizeChange({ platform, formatId }) {
    setPendingPlatform(platform);
    setPendingFormatId(formatId || '');
    setMediums(formatId ? [formatId] : []);
  }
  const OTHER_FORMATS = POST_FORMATS.filter((f) => f.isCarousel || f.isVideo);
  function handleOtherFormat(formatId) {
    setPendingPlatform('');
    setPendingFormatId(formatId);
    setMediums(formatId ? [formatId] : []);
  }

  function toggleFrom(setter) {
    return (value) => setter((prev) => (prev.includes(value) ? prev.filter((x) => x !== value) : [...prev, value]));
  }
  const toggleMood = toggleFrom(setMoodTags);
  const toggleStyleReference = toggleFrom(setStyleReferences);
  const togglePeopleAge = toggleFrom(setPeopleAge);

  async function handleSuggestLookAndFeel() {
    setSuggestingLook(true);
    setLookSuggestionError('');
    setLookSuggestionRationale('');
    try {
      const { moodTags: mt, styleReferences: sr, lightingStyle: ls, compositionStyle: cs, rationale } =
        await postsApi.suggestLookAndFeel({ purpose, briefNote, mediums, followBrand });
      setMoodTags(mt);
      setStyleReferences(sr);
      if (ls) setLightingStyle(ls);
      if (cs) setCompositionStyle(cs);
      setLookSuggestionRationale(rationale || '');
    } catch (e) {
      setLookSuggestionError(apiErrorInfo(e));
    } finally {
      setSuggestingLook(false);
    }
  }

  // "Suggest" on one section at a time. The look-and-feel call returns mood, style, lighting and composition; each link
  // applies only its own part. The visual description is drafted from the message call.
  const [suggestBusy, setSuggestBusy] = useState('');
  const [suggestErr, setSuggestErr] = useState({ section: '', error: '' });
  const [suggestNote, setSuggestNote] = useState({ section: '', text: '' });
  async function suggestSection(section) {
    setSuggestBusy(section);
    setSuggestErr({ section: '', error: '' });
    setSuggestNote({ section: '', text: '' });
    try {
      if (section === 'visual') {
        const r = await postsApi.suggestMessage({ purpose, briefNote, mediums, moodTags, styleReferences, followBrand });
        const draft = [r.primaryMessage, r.mustInclude ? `Include: ${r.mustInclude}.` : ''].filter(Boolean).join(' ');
        if (draft) setBriefNote(draft);
        setSuggestNote({ section, text: r.rationale || '' });
      } else {
        const r = await postsApi.suggestLookAndFeel({ purpose, briefNote, mediums, followBrand });
        if (section === 'mood') setMoodTags(r.moodTags || []);
        if (section === 'style') setStyleReferences(r.styleReferences || []);
        if (section === 'look') {
          if (r.lightingStyle) setLightingStyle(r.lightingStyle);
          if (r.compositionStyle) setCompositionStyle(r.compositionStyle);
        }
        if (section === 'people') {
          // No separate people suggestion exists yet: product-led styles mean no people, everything else includes them.
          const productLed = (r.styleReferences || []).some((x) => ['Flat lay top-down', 'Studio product photography', 'Architectural / geometric', 'Bold graphic / typographic'].includes(x));
          setPeopleMode(productLed ? 'none' : 'include');
        }
        setSuggestNote({ section, text: r.rationale || '' });
      }
    } catch (e) {
      setSuggestErr({ section, error: apiErrorInfo(e) });
    } finally {
      setSuggestBusy('');
    }
  }
  const sugProps = (section) => ({
    onSuggest: () => suggestSection(section),
    loading: suggestBusy === section,
    error: suggestErr.section === section ? suggestErr.error : '',
    rationale: suggestNote.section === section ? suggestNote.text : ''
  });

  async function handleSuggestMessage() {
    setSuggestingMessage(true);
    setMessageSuggestionError('');
    setMessageSuggestionRationale('');
    try {
      const { primaryMessage: pm, mustInclude: mi, mustAvoid: ma, rationale } =
        await postsApi.suggestMessage({ purpose, briefNote, mediums, moodTags, styleReferences, followBrand });
      if (pm) setPrimaryMessage(pm);
      setMustInclude(mi || '');
      setMustAvoid(ma || '');
      setMessageSuggestionRationale(rationale || '');
    } catch (e) {
      setMessageSuggestionError(apiErrorInfo(e));
    } finally {
      setSuggestingMessage(false);
    }
  }

  function toggleAsset(id) {
    setSelectedAssets((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        // Deselecting an asset should never leave a stale "keep exact" flag behind.
        setExactAssets((prevExact) => {
          if (!prevExact.has(id)) return prevExact;
          const nextExact = new Set(prevExact);
          nextExact.delete(id);
          return nextExact;
        });
      } else {
        next.add(id);
      }
      return next;
    });
  }

  function toggleExactAsset(id, e) {
    e.stopPropagation(); // don't also toggle selection when clicking the checkbox
    setExactAssets((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  function stageReferenceFile(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    // Adaptation has no UI to pick a reference mode (the Reference Creatives
    // step is skipped entirely) - always template, never whatever stale
    // referenceMode value might be left over from a prior New Creative session.
    const mode =
      creativeType === 'adaptation' ? 'template' : referenceMode === 'style' ? 'style' : referenceMode === 'template' ? 'template' : 'include';
    const exact = creativeType !== 'adaptation' && referenceMode === 'exact';
    setStagedReferences((prev) => [...prev, { file, mode, exact, previewUrl: URL.createObjectURL(file) }]);
  }

  // Separate from the main template upload above - this is specifically
  // for elements that must be guaranteed pixel-perfect (a logo, a QR code,
  // compliance/registration text). Always exact:true regardless of
  // referenceMode, and defaults to bottom-right until the person picks a
  // different corner via setStagedReferenceAnchor. See
  // compositeExactAssets.js for how multiple corners get laid out.
  function stageExactElement(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setStagedReferences((prev) => [
      ...prev,
      { file, mode: 'include', exact: true, anchor: 'bottom-right', previewUrl: URL.createObjectURL(file) }
    ]);
  }

  function setStagedReferenceAnchor(index, anchor) {
    setStagedReferences((prev) => prev.map((r, i) => (i === index ? { ...r, anchor } : r)));
  }

  async function handleGenerateHeadlineVariations() {
    setGeneratingHeadlines(true);
    setHeadlineError('');
    try {
      const { variations } = await aiApi.generateHeadlineVariations({ originalHeadline, purpose, briefNote });
      setHeadlineOptions(variations || []);
    } catch (err) {
      setHeadlineError(apiErrorInfo(err));
    } finally {
      setGeneratingHeadlines(false);
    }
  }

  // The main "Creative to adapt" upload for Creative Adaptation. Separate
  // from stageReferenceFile above because this one also triggers AI
  // detection of what's actually in the image (logo, key visual, secondary
  // text, compliance text, decorative graphics) so the preservation
  // checkboxes below can default to what's actually there, rather than
  // the person having to identify every element themselves. Detection
  // failing is never treated as blocking - it falls back to "assume
  // everything should be preserved" (the safer default) either way.
  async function stageTemplateFile(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    // Re-uploading replaces the current original (and everything derived from it).
    setStagedReferences((prev) => {
      prev.filter((r) => r.mode === 'template').forEach((r) => URL.revokeObjectURL(r.previewUrl));
      return [...prev.filter((r) => r.mode !== 'template'), { file, mode: 'template', exact: false, previewUrl: URL.createObjectURL(file) }];
    });
    setTemplateAnalysis(null);
    setRegionBoxes({});
    setHoveredRegion(null);
    setOriginalHeadline('');
    setHeadlineOptions([]);
    setSelectedHeadline('');
    setCustomHeadline('');
    setPreservation((p) => ({ ...p, protectedRegions: [] }));
    setPreserveModalOpen(false);
    setAnalyzingTemplate(true);
    try {
      const result = await aiApi.analyzeTemplate(file);
      setTemplateAnalysis(result);
      setPreserveModalOpen(true);
      if (result.detected) {
        setPreservation((prev) => ({
          protectedRegions: prev.protectedRegions || [],
          customInstruction: prev.customInstruction || '',
          preserveLogo: result.elements.hasLogo,
          preserveKeyVisual: result.elements.hasKeyVisual,
          preserveSecondaryText: result.elements.hasSecondaryText,
          preserveComplianceText: result.elements.hasComplianceText,
          preserveDecorative: result.elements.hasDecorativeGraphics,
          preserveBackground: result.elements.hasBackground,
          ...(result.elements.hasPrimaryHeadline && result.elements.primaryHeadlineText ? { preservePrimaryHeadline: true } : {}),
          layoutFlexible: false
        }));
        // We now KNOW rather than have to ask - answer the compliance
        // question automatically instead of leaving it for the person to
        // notice and self-report.
        if (result.elements.hasComplianceText) setHasComplianceElements(true);
        if (result.elements.hasPrimaryHeadline && result.elements.primaryHeadlineText) {
          setOriginalHeadline(result.elements.primaryHeadlineText);
        }
      }
    } catch (err) {
      setTemplateAnalysis({ detected: false, reason: 'Analysis failed - defaulting to preserving everything. Use Review & edit to adjust.' });
      setPreserveModalOpen(true);
    } finally {
      setAnalyzingTemplate(false);
    }
  }

  function unstageReference(index) {
    setStagedReferences((prev) => {
      const removed = prev[index];
      URL.revokeObjectURL(removed.previewUrl);
      if (removed.mode === 'template') {
        setTemplateAnalysis(null);
        setAnalyzingTemplate(false);
        setOriginalHeadline('');
        setHeadlineOptions([]);
        setSelectedHeadline('');
        setCustomHeadline('');
        setPreservation((p) => ({ ...p, protectedRegions: [] }));
        setHoveredRegion(null);
        setRegionBoxes({});
        setPreserveModalOpen(false);
      }
      return prev.filter((_, i) => i !== index);
    });
  }

  async function handleStockSearch(e) {
    e?.preventDefault();
    if (!stockQuery.trim()) return;
    setStockSearching(true);
    setStockError('');
    try {
      const { photos } = await stockPhotosApi.search(stockQuery.trim());
      setStockResults(photos);
    } catch (err) {
      setStockError(apiErrorMessage(err));
      setStockResults([]);
    } finally {
      setStockSearching(false);
    }
  }

  // Downloads the chosen stock photo client-side and stages it as a real
  // File, so it flows through the exact same upload pipeline as a locally
  // picked file (postsApi.uploadReference) - no server-side changes needed
  // beyond the search itself.
  async function handleAddStockPhoto(photo) {
    setAddingStockId(photo.id);
    setStockError('');
    try {
      const res = await fetch(photo.fullUrl);
      if (!res.ok) throw new Error('Could not download that image.');
      const blob = await res.blob();
      const ext = (blob.type.split('/')[1] || 'jpg').replace('jpeg', 'jpg');
      const file = new File([blob], `pexels-${photo.id}.${ext}`, { type: blob.type });
      const mode = referenceMode === 'style' ? 'style' : referenceMode === 'template' ? 'template' : 'include';
      const exact = referenceMode === 'exact';
      setStagedReferences((prev) => [
        ...prev,
        { file, mode, exact, previewUrl: photo.previewUrl, credit: photo.photographer ? `Photo by ${photo.photographer} on Pexels` : '' }
      ]);
    } catch (err) {
      setStockError(apiErrorMessage(err));
    } finally {
      setAddingStockId(null);
    }
  }

  // Opens the full stock-photo search results as a browsable lightbox set -
  // prev/next arrows page through every result, and the "Select Photo" CTA
  // calls the exact same handleAddStockPhoto used by the grid's quick-add
  // "+" button, just reached from inside the lightbox instead.
  function openStockLightbox(startIndex) {
    openLightbox({
      index: startIndex,
      items: stockResults.map((photo) => ({
        src: photo.fullUrl || photo.previewUrl,
        alt: photo.alt || 'Stock photo',
        title: photo.alt || 'Stock photo',
        meta: [
          { label: 'Photographer', value: photo.photographer || 'Unknown' },
          { label: 'Source', value: 'Pexels' }
        ],
        data: photo
      })),
      cta: {
        label: referenceMode === 'style' ? 'Select as style reference' : referenceMode === 'exact' ? 'Select as exact asset' : referenceMode === 'template' ? 'Select as template' : 'Select Photo',
        onClick: (item) => handleAddStockPhoto(item.data)
      }
    });
  }

  async function handleGenerate({ resetDesigns = false } = {}) {
    setError('');
    setLoading(true);
    try {
      const briefPayload = {
        creativeType,
        purpose,
        mediums: mediums.length ? mediums : ['instagram_feed'],
        briefNote,
        selectedAssets: [...selectedAssets],
        exactAssetIds: [...exactAssets],
        creativeBrief: {
          moodTags,
          styleReferences,
          lightingStyle,
          compositionStyle,
          primaryMessage,
          mustInclude,
          mustAvoid,
          qualityTier,
          useBrandStyle,
          followBrand,
          peopleMode,
          peopleCount: peopleMode === 'include' ? peopleCount : '',
          peopleAge: peopleMode === 'include' ? peopleAge : [],
          peopleGender: peopleMode === 'include' ? peopleGender : '',
          peopleStyle: peopleMode === 'include' ? peopleStyle : '',
          peopleEthnicity: peopleMode === 'include' ? peopleEthnicity : '',
          peopleNote: peopleMode === 'include' ? peopleNote : '',
          // Adaptation with a detected original headline means the
          // template inherently has baked-in text to preserve/vary - the
          // "no baked-in text, leave clean caption space" default (which
          // makes sense for New Creative) would directly contradict the
          // template-preservation instruction telling the model to
          // reproduce the headline. Force it on in that specific case;
          // otherwise leave whatever New Creative's Generation Settings
          // step actually set.
          includeTypography: creativeType === 'adaptation' && originalHeadline ? true : includeTypography,
          slideCount,
          ...(creativeType === 'adaptation' && originalHeadline ? { headlineText: preservation.preservePrimaryHeadline === false ? selectedHeadline : originalHeadline } : {}),
          ...(creativeType === 'adaptation' ? { templatePreservation: preservation } : {})
        }
      };

      // Revisiting an existing post (e.g. navigated back from Step 02/03)
      // updates it in place, preserving whatever was already generated -
      // only a genuinely new post (no post in context yet) creates one.
      // Designs are only ever wiped when resetDesigns is explicitly
      // requested via the separate "Start over" action below.
      const { post: saved } = post?._id
        ? await postsApi.update(post._id, { ...briefPayload, ...(resetDesigns ? { resetDesigns: true } : {}) })
        : await postsApi.create(briefPayload);

      // References need a real post to attach to, so they're uploaded here
      // rather than at creation time. Best-effort: one failing shouldn't
      // block the workflow (Step 02 has the same uploader to re-add it).
      for (const ref of stagedReferences) {
        try {
          await postsApi.uploadReference(saved._id, ref.file, ref.mode, ref.exact, ref.anchor || 'bottom-right');
        } catch (err) {
          console.warn('Reference creative failed to upload:', ref.file.name, err);
        }
      }
      stagedReferences.forEach((ref) => URL.revokeObjectURL(ref.previewUrl));
      setStagedReferences([]);

      skipDraftSave.current = true;
      setBriefDraft(null);
      setPost(saved);
      navigate('/designs');
    } catch (e) {
      setError(apiErrorInfo(e));
    } finally {
      setLoading(false);
    }
  }

  const hasExistingDesigns = (post?.designs?.length || 0) > 1;

  function handleStartOver() {
    if (!window.confirm('This will discard your current copy directions and any generated images for this post. Continue?')) return;
    handleGenerate({ resetDesigns: true });
  }

  const preview = post?.designs?.[0];
  // Creative Adaptation strictly follows the uploaded template rather than
  // taking new creative direction, so Look & feel (mood/style/lighting/
  // composition) and Message & constraints (primary message/must-include/
  // must-avoid) would just be conflicting instructions fighting the "keep
  // it as close to the original as possible" instruction already baked
  // into template mode. Reference Creatives (the general-purpose, four-mode
  // picker) is also skipped in favor of a single-purpose upload folded
  // directly into Basics below - Adaptation only ever needs one thing
  // (the template), not brand-asset selection/stock search/style refs.
  const activeSteps =
    creativeType === 'adaptation' ? MAIN_STEPS.filter((s) => !['look', 'message', 'sources'].includes(s.key)) : MAIN_STEPS;
  const step = activeSteps[stepIndex];
  const isFirstStep = stepIndex === 0;
  const isLastStep = stepIndex === activeSteps.length - 1;

  function goNext() {
    setStepIndex((i) => Math.min(i + 1, activeSteps.length - 1));
  }
  function goBack() {
    setStepIndex((i) => Math.max(i - 1, 0));
  }

  const creativeDirectionCount = [
    moodTags.length > 0,
    styleReferences.length > 0,
    Boolean(lightingStyle),
    Boolean(compositionStyle),
    Boolean(primaryMessage.trim()),
    Boolean(mustInclude.trim()),
    Boolean(mustAvoid.trim()),
    peopleMode !== 'auto',
    stagedReferences.length > 0
  ].filter(Boolean).length;

  // Leaving the brief (sidebar link / Back) asks first once anything has been entered or the person is past step 1.
  const briefHasProgress = !atHome && (creativeType === 'new' || creativeType === 'adaptation')
    && (stepIndex > 0 || creativeDirectionCount > 0 || Boolean(briefNote.trim()) || mediums.length > 0);
  useLeaveGuard(briefHasProgress);

  // Start screen - shown before a flow is chosen, or whenever the person opens Generate Media from the sidebar.
  // Deliberately rendered without the numbered Stepper (Layout only shows it when `step` is passed) since
  // choosing a flow isn't itself a step.
  const customNames = Object.fromEntries(customFeatures.map((cf) => [cf.id, cf.name]));
  const activeTask = getActiveTask({ post, creativeType, stepIndex, customNames });

  // Starts a flow from the start screen. Every flow keeps its existing journey; if another task is still in
  // progress it is replaced (a saved post stays in Saved Documents).
  function startFlow(type) {
    // No confirm: starting a new task silently replaces the one in progress.
    if (activeTask) startFresh();
    handleSelectCreativeType(type);
    setAtHome(false);
  }

  // Finish Up: back into the task in progress, at the step it had reached.
  function resumeTask(task) {
    if (!task) return;
    if (task.route === '/generate') setAtHome(false);
    else navigate(task.route);
  }

  // "Adapt now" / "Convert now" cards on the last screens of other flows land here with { start: 'resize' | 'convert' }.
  const startedFromHandoff = useRef(false);
  useEffect(() => {
    const kind = location.state?.start;
    if (!kind || startedFromHandoff.current) return;
    startedFromHandoff.current = true;
    startFlow(kind);
    navigate(location.pathname, { replace: true, state: {} });
  }, [location.key]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!creativeType || atHome) {
    return (
      <Layout eyebrow="Get started" title="Generate Media">
        <GenerateHome activeTask={activeTask} customFeatures={customFeatures} onStart={startFlow} onResume={resumeTask} />
      </Layout>
    );
  }

  // A custom feature from Brief Studio ("custom:<id>") - its own form + run, never enters the post wizard.
  if (typeof creativeType === 'string' && creativeType.startsWith('custom:')) {
    return <CustomFeatureRunner key={creativeType} featureId={creativeType.slice('custom:'.length)} onBack={startFresh} />;
  }

  // "Quick Adapt" - upload a finished creative and go straight to Adapt Creative.
  if (creativeType === 'resize') {
    return <AdaptEditor onBack={startFresh} />;
  }

  // "Convert to Video" - upload an image, pick its motion and video size, download the video.
  if (creativeType === 'convert') {
    return <ConvertVideoEditor onBack={startFresh} />;
  }

  // "Change Hero Image Only" - same short flow as Edit Headline Only, for the main image.
  if (creativeType === 'hero') {
    return <HeroEditor onBack={startFresh} />;
  }

  // "Edit Headline Only" is its own short flow (upload -> edit text -> Modify -> Publish)
  // with none of the brief steps, so it renders its own page.
  if (creativeType === 'headline') {
    return <HeadlineEditor onBack={startFresh} />;
  }

  return (
    <Layout
      title={
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          {creativeType ? (
            <button
              type="button"
              onClick={startFresh}
              title="Start a new one"
              style={{ background: 'none', border: 'none', padding: 0, margin: 0, font: 'inherit', color: 'inherit', cursor: 'pointer', textDecoration: 'underline', textDecorationColor: 'var(--line)', textUnderlineOffset: 5 }}
            >
              Generate Media
            </button>
          ) : (
            <span>Generate Media</span>
          )}
          {creativeType && (
            <>
              <span aria-hidden="true" style={{ color: 'var(--muted)', fontWeight: 400 }}>&rsaquo;</span>
              <span style={{ color: 'var(--blue)' }}>{creativeType === 'adaptation' ? 'Creative Adaptation' : 'New Creative'}</span>
            </>
          )}
        </span>
      }
      step={creativeType === 'adaptation' ? 'generate' : step.key === 'look' ? 'visual' : ['basics', 'brief'].includes(step.key) ? 'purpose' : 'messaging'}
      flow={creativeType === 'adaptation' ? 'adaptation' : 'new'}
      onStep={(key) => {
        const target = { purpose: 'basics', visual: 'look', messaging: 'message' }[key];
        const idx = activeSteps.findIndex((x) => x.key === target);
        if (idx >= 0) setStepIndex(idx);
      }}
      reachable={['purpose', 'visual', 'messaging']}
    >
      {creativeType !== 'adaptation' && (
        <div className="page-lede">
          <p>Tell AUTOMATr what this post is for, and it'll build the first draft.</p>
        </div>
      )}

      {hadExistingPost.current && (
        <div className="notice-banner" style={{ marginBottom: 18 }}>
          <strong>Continuing your last brief{post?.purpose ? ` (${post.purpose})` : ''}.</strong>
          <p style={{ margin: '4px 0 8px' }}>Change anything below to adjust it, or start over completely.</p>
          <Btn variant="secondary" onClick={startFresh}>Start from scratch</Btn>
        </div>
      )}

      <AiErrorNotice error={error} />

      <div className="grid-2" style={creativeType === 'adaptation' ? { gridTemplateColumns: 'minmax(0, 1fr)' } : undefined}>
        <div>
          <Card>
            <div className="wizard-progress" style={{ marginBottom: 14 }}>
              {activeSteps.map((s, i) => (
                <button
                  key={s.key}
                  type="button"
                  className={`wizard-dot ${i === stepIndex ? 'active' : ''} ${i < stepIndex ? 'done' : ''}`}
                  onClick={() => setStepIndex(i)}
                  title={s.label}
                  aria-label={s.label}
                />
              ))}
            </div>
            <p className="hint" style={{ marginBottom: 22 }}>
              Step {stepIndex + 1} of {activeSteps.length} — {step.label}
            </p>

            <input ref={referenceFileInputRef} type="file" accept="image/png,image/jpeg,image/webp" style={{ display: 'none' }} onChange={stageReferenceFile} />
            <input ref={templateFileInputRef} type="file" accept="image/png,image/jpeg,image/webp" style={{ display: 'none' }} onChange={stageTemplateFile} />
            <input ref={exactElementFileInputRef} type="file" accept="image/png,image/jpeg,image/webp" style={{ display: 'none' }} onChange={stageExactElement} />

            <div key={step.key} className="wizard-step-fade">
              {step.key === 'basics' && (
                <>
                  {creativeType === 'adaptation' && !stagedReferences.some((r) => r.mode === 'template') && (
                    <Field
                      label="Original Creative"
                      hint="Upload the existing, already-approved creative. AUTOMATr keeps its logo, layout, and branding as close to the original as possible and only adapts the copy for your new brief below."
                    >
                      <Btn variant="secondary" onClick={() => templateFileInputRef.current?.click()}>
                        + Upload the creative to adapt
                      </Btn>
                    </Field>
                  )}

                  {creativeType === 'adaptation' && stagedReferences.some((r) => r.mode === 'template') && (
                    <Field label="What should we preserve from the original?">
                      {analyzingTemplate && <AnalyzingIndicator />}
                      {!analyzingTemplate && templateAnalysis && (
                        <>
                          {!templateAnalysis.detected && (
                            <p className="hint" style={{ marginBottom: 10 }}>
                              Couldn't auto-detect elements ({templateAnalysis.reason || 'analysis unavailable'}) - defaulting to
                              preserving everything. Use Review & edit to adjust.
                            </p>
                          )}
                          {(() => {
                            const tpl = stagedReferences.find((r) => r.mode === 'template');
                            const el = templateAnalysis.detected ? templateAnalysis.elements : null;
                            const known = (flag) => (el ? el[flag] : true);
                            const isOn = (prop) => preservation[prop] !== false;
                            const flip = (prop) => () => setPreservation((p) => ({ ...p, [prop]: p[prop] === false }));
                            const items = [
                              { show: known('hasLogo'), prop: 'preserveLogo', key: 'logo', title: 'Logo', color: '#e11d48', description: el?.logoDescription || 'Brand logo / lockup', onLabel: 'Keep exactly', offLabel: 'Free to change' },
                              { show: Boolean(el && el.hasPrimaryHeadline && el.primaryHeadlineText), prop: 'preservePrimaryHeadline', key: 'primaryHeadline', title: 'Primary headline', color: '#2563eb', description: el?.primaryHeadlineText ? `\u201c${el.primaryHeadlineText}\u201d` : 'Main headline', onLabel: 'Keep wording & style', offLabel: 'Write a new headline' },
                              { show: known('hasKeyVisual'), prop: 'preserveKeyVisual', key: 'keyVisual', title: 'Key visual / hero', color: '#16a34a', description: el?.keyVisualDescription || 'Main subject of the creative', onLabel: 'Keep exactly', offLabel: 'Will be replaced' },
                              { show: known('hasBackground'), prop: 'preserveBackground', key: 'background', title: 'Background / setting', color: '#d97706', description: el?.backgroundDescription || 'Scene / location', onLabel: 'Keep exactly', offLabel: 'Will be replaced' },
                              { show: known('hasSecondaryText'), prop: 'preserveSecondaryText', key: 'secondaryText', title: 'Secondary text', color: '#9333ea', description: el?.secondaryTextDescription || 'Tagline / callout block', onLabel: 'Keep in place', offLabel: 'Free to change' },
                              { show: known('hasComplianceText'), prop: 'preserveComplianceText', key: 'complianceText', title: 'Compliance / QR', color: '#ea580c', description: el?.complianceTextDescription || 'Small print, legal text or QR code', onLabel: 'Keep in place', offLabel: 'May be omitted' },
                              { show: known('hasDecorativeGraphics'), prop: 'preserveDecorative', key: 'decorative', title: 'Decorative graphics', color: '#0891b2', description: el?.decorativeDescription || 'Icons, borders, patterns', onLabel: 'Keep', offLabel: 'Free to change' }
                            ]
                              .filter((i) => i.show)
                              .map((i) => ({ ...i, active: isOn(i.prop), onToggle: flip(i.prop) }));
                            const setAll = (value) =>
                              setPreservation((p) => ({ ...p, ...Object.fromEntries(items.map((i) => [i.prop, value])) }));

                            const regions = el?.regions || {};
                            const SHORT = { primaryHeadline: 'Headline', keyVisual: 'Key visual', complianceText: 'Compliance', secondaryText: 'Secondary text', decorative: 'Decorative' };
                            const regionDefs = items
                              .filter((i) => regions[i.key])
                              .map((i) => ({ key: i.key, label: SHORT[i.key] || i.title, color: '#2E5EFF', active: i.active, toggle: i.onToggle, box: regionBoxes[i.key] || regions[i.key] }));
                            const layout = {
                              flexible: Boolean(preservation.layoutFlexible),
                              summary: el?.layoutSummary || '',
                              onChange: (flexible) => setPreservation((p) => ({ ...p, layoutFlexible: flexible }))
                            };
                            const replaceCreative = () => templateFileInputRef.current?.click();

                            return (
                              <>
                                <PreservationSummary
                                  imageSrc={tpl?.previewUrl}
                                  items={items}
                                  layoutFlexible={layout.flexible}
                                  protectedCount={(preservation.protectedRegions || []).length}
                                  onReview={() => { setPreserveTab('elements'); setPreserveModalOpen(true); }}
                                  onProtect={() => { setPreserveTab('protect'); setPreserveModalOpen(true); }}
                                  onReplace={replaceCreative}
                                />
                                <PreservationLightbox
                                  open={preserveModalOpen}
                                  onClose={() => {
                                    setPreserveModalOpen(false);
                                    setHoveredRegion(null);
                                  }}
                                  imageSrc={tpl?.previewUrl}
                                  tab={preserveTab}
                                  onTab={setPreserveTab}
                                  protectedCount={(preservation.protectedRegions || []).length}
                                  protectSlot={
                                    <ProtectedRegionOverlay
                                      src={tpl?.previewUrl}
                                      regions={preservation.protectedRegions || []}
                                      onChange={(next) => setPreservation((p) => ({ ...p, protectedRegions: next }))}
                                    />
                                  }
                                  regionDefs={regionDefs}
                                  showOutlines={showOutlines}
                                  onShowOutlines={setShowOutlines}
                                  hoveredKey={hoveredRegion}
                                  onHover={setHoveredRegion}
                                  onReupload={replaceCreative}
                                  onChangeBox={(key, box) => setRegionBoxes((p) => ({ ...p, [key]: box }))}
                                  hasBoxEdits={Object.keys(regionBoxes).length > 0}
                                  onResetBoxes={() => setRegionBoxes({})}
                                  items={items}
                                  layout={layout}
                                  onSetAll={(value) => setPreservation((p) => ({ ...p, ...Object.fromEntries(items.map((i) => [i.prop, value])) }))}
                                  note={!el ? 'Automatic detection was not available, so every element defaults to kept. Adjust them here.' : ''}
                                />
                              </>
                            );
                          })()}
                          {SHOW_EXACT_ASSET_UPLOAD && (preservation.preserveLogo || preservation.preserveComplianceText) && (
                            <div style={{ margin: '0 0 18px', padding: '12px 14px', border: '1px dashed var(--line)', borderRadius: 12, background: 'var(--paper)' }}>
                              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)' }}>
                                Guarantee logo / QR / legal text exactly <span className="hint" style={{ fontWeight: 400 }}>(optional)</span>
                              </div>
                              <p className="hint" style={{ margin: '4px 0 10px' }}>
                                Keeping an element only asks the AI to preserve it - it can still redraw it slightly, and can't guarantee legal accuracy for a registration number or QR code. Upload a cropped copy of anything that must never change: it is pasted onto the finished image completely untouched, at the corner you choose.
                              </p>
                              {stagedReferences.some((r) => r.exact) && (
                            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 12 }}>
                              {stagedReferences.map(
                                (ref, i) =>
                                  ref.exact && (
                                    <div key={i} style={{ textAlign: 'center', width: 108 }}>
                                      <div
                                        style={{
                                          width: 64,
                                          height: 64,
                                          margin: '0 auto',
                                          borderRadius: 8,
                                          border: '1px solid var(--line)',
                                          backgroundImage: `url(${ref.previewUrl})`,
                                          backgroundSize: 'cover',
                                          backgroundPosition: 'center'
                                        }}
                                      />
                                      <select
                                        value={ref.anchor || 'bottom-right'}
                                        onChange={(e) => setStagedReferenceAnchor(i, e.target.value)}
                                        style={{ fontSize: 11, marginTop: 6, width: '100%' }}
                                      >
                                        <option value="top-left">Top-left</option>
                                        <option value="top-right">Top-right</option>
                                        <option value="bottom-left">Bottom-left</option>
                                        <option value="bottom-right">Bottom-right</option>
                                      </select>
                                      <button type="button" className="link-btn" style={{ fontSize: 11 }} onClick={() => unstageReference(i)}>
                                        Remove
                                      </button>
                                    </div>
                                  )
                              )}
                            </div>
                          )}
                          <Btn variant="secondary" onClick={() => exactElementFileInputRef.current?.click()}>
                            + Add exact element
                          </Btn>
                            </div>
                          )}
                          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)', margin: '2px 0 6px' }}>
                            Specific changes to make <span className="hint" style={{ fontWeight: 400 }}>(optional)</span>
                          </div>
                          <textarea
                            rows={3}
                            maxLength={1000}
                            placeholder="e.g. Change the background from Paris to a Mumbai street at golden hour. Keep the car exactly the same."
                            value={preservation.customInstruction || ''}
                            onChange={(e) => setPreservation((p) => ({ ...p, customInstruction: e.target.value }))}
                          />
                          <p className="hint" style={{ marginTop: 6 }}>
                            Tell the AI exactly what to change in the original - background, location, time of day, colours, props, anything. These changes take priority over the ticked boxes above; everything else stays as set.
                          </p>
                        </>
                      )}
                    </Field>
                  )}

                  <Field label="Purpose">
                    <select value={purpose} onChange={(e) => setPurpose(e.target.value)}>
                      {PURPOSES.map((p) => <option key={p}>{p}</option>)}
                    </select>
                  </Field>

                  <Field label="Format" hint="This is your master creative - generated at the correct size for this exact spot. You can port it to other platforms/sizes later, at Publish.">
                    <div className="nc-sizepick">
                      <SizePicker
                        mode="image"
                        platform={pendingPlatform}
                        formatId={OTHER_FORMATS.some((f) => f.id === pendingFormatId) ? '' : pendingFormatId}
                        onChange={handleSizeChange}
                        idPrefix="brief-size"
                      />
                      <div className="nc-sizepick__other">
                        <select aria-label="Carousel or video format" value={OTHER_FORMATS.some((f) => f.id === pendingFormatId) ? pendingFormatId : ''} onChange={(e) => handleOtherFormat(e.target.value)}>
                          <option value="">Carousel or video format (optional)</option>
                          {OTHER_FORMATS.map((f) => <option key={f.id} value={f.id}>{f.isVideo ? '🎥 ' : ''}{f.platform} {f.label} ({f.ratio})</option>)}
                        </select>
                      </div>
                    </div>
                  </Field>

                  {getFormat(pendingFormatId).isVideo && (
                    <p className="hint" style={{ marginTop: -10, marginBottom: 18 }}>
                      🎥 {getFormat(pendingFormatId).platform} {getFormat(pendingFormatId).label} is a video format ({getFormat(pendingFormatId).videoAspectRatio}, up to {getFormat(pendingFormatId).maxDurationSeconds}s - {getFormat(pendingFormatId).recommendedDurationSeconds}s recommended).
                      No still image is generated for it - once you've picked a copy direction on Step 02, use "Generate video" there to produce the actual creative.
                    </p>
                  )}

                  {isCarouselFormat(pendingFormatId) && (
                    <Field
                      label="Number of slides"
                      hint={
                        getFormat(pendingFormatId).notSwipeable
                          ? `X shows up to ${getFormat(pendingFormatId).maxSlides} images as a grid, not a swipe-through carousel.`
                          : `Between ${getFormat(pendingFormatId).minSlides} and ${getFormat(pendingFormatId).maxSlides} slides - each gets a distinct role (hook, context, detail, proof, call to action) so the set reads as a sequence.`
                      }
                    >
                      <input
                        type="number"
                        min={getFormat(pendingFormatId).minSlides}
                        max={getFormat(pendingFormatId).maxSlides}
                        value={slideCount}
                        onChange={(e) => {
                          const { minSlides, maxSlides } = getFormat(pendingFormatId);
                          const next = Math.min(Math.max(Number(e.target.value) || minSlides, minSlides), maxSlides);
                          setSlideCount(next);
                        }}
                      />
                    </Field>
                  )}
                </>
              )}

              {step.key === 'brief' && (
                <FieldWithSuggest label="Brief / notes" hint="Optional - describe the visual and anything AUTOMATr should know (offer details, tone, keywords)." cost={<CostTag estimate={costs?.suggestion} />} {...sugProps('visual')}>
                  <textarea
                    placeholder="e.g. Autumn collection teaser, mention free shipping over $75"
                    value={briefNote}
                    onChange={(e) => setBriefNote(e.target.value)}
                  />
                </FieldWithSuggest>
              )}

              {step.key === 'look' && (
                <>
                  <p className="hint" style={{ margin: '0 0 16px' }}>
                    Pick these by hand, or use Suggest on any section to get a direction from your purpose and brief.
                  </p>

                  <FieldWithSuggest label="Mood / tone" hint="Pick as many as apply. Optional - skip ahead if you don't have a strong preference." cost={<CostTag estimate={costs?.suggestion} />} {...sugProps('mood')}>
                    <div className="chip-row">
                      {MOOD_TAGS.map((m) => (
                        <Chip key={m} selected={moodTags.includes(m)} onClick={() => toggleMood(m)}>{m}</Chip>
                      ))}
                    </div>
                  </FieldWithSuggest>

                  <FieldWithSuggest label="Visual style reference" hint="Pick as many as apply - this steers the AI's photographic/illustrative approach." cost={<CostTag estimate={costs?.suggestion} />} {...sugProps('style')}>
                    <div className="chip-row">
                      {STYLE_REFERENCES.map((s) => (
                        <Chip key={s} selected={styleReferences.includes(s)} onClick={() => toggleStyleReference(s)}>{s}</Chip>
                      ))}
                    </div>
                  </FieldWithSuggest>

                  <FieldWithSuggest label="People" hint="Should the final design feature people? AI-generated, fictional people only - never a real or recognisable person." cost={<CostTag estimate={costs?.suggestion} />} {...sugProps('people')}>
                    <div className="chip-row">
                      <Chip selected={peopleMode === 'auto'} onClick={() => setPeopleMode('auto')}>Let AI decide (default)</Chip>
                      <Chip selected={peopleMode === 'include'} onClick={() => setPeopleMode('include')}>Include people</Chip>
                      <Chip selected={peopleMode === 'none'} onClick={() => setPeopleMode('none')}>No people</Chip>
                    </div>
                    {peopleMode === 'include' && (
                      <div style={{ marginTop: 12, padding: 14, border: '1px solid var(--line)', borderRadius: 12, display: 'flex', flexDirection: 'column', gap: 12 }}>
                        <div>
                          <p className="hint" style={{ margin: '0 0 6px' }}><strong>How many</strong> (optional)</p>
                          <div className="chip-row">
                            {PEOPLE_COUNTS.map((c) => (
                              <Chip key={c} selected={peopleCount === c} onClick={() => setPeopleCount(peopleCount === c ? '' : c)}>{c}</Chip>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="hint" style={{ margin: '0 0 6px' }}><strong>Age group</strong> (pick any)</p>
                          <div className="chip-row">
                            {PEOPLE_AGES.map((a) => (
                              <Chip key={a} selected={peopleAge.includes(a)} onClick={() => togglePeopleAge(a)}>{a}</Chip>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="hint" style={{ margin: '0 0 6px' }}><strong>Gender</strong> (optional - tap again to clear)</p>
                          <div className="chip-row">
                            {PEOPLE_GENDERS.map((gn) => (
                              <Chip key={gn} selected={peopleGender === gn} onClick={() => setPeopleGender(peopleGender === gn ? '' : gn)}>{gn}</Chip>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="hint" style={{ margin: '0 0 6px' }}><strong>Ethnicity</strong> (Indian by default - tap again to clear)</p>
                          <div className="chip-row">
                            {PEOPLE_ETHNICITIES.map((eth) => (
                              <Chip key={eth} selected={peopleEthnicity === eth} onClick={() => setPeopleEthnicity(peopleEthnicity === eth ? '' : eth)}>{eth}</Chip>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="hint" style={{ margin: '0 0 6px' }}><strong>How they appear</strong> (optional)</p>
                          <div className="chip-row">
                            {PEOPLE_STYLES.map((p) => (
                              <Chip key={p} selected={peopleStyle === p} onClick={() => setPeopleStyle(peopleStyle === p ? '' : p)}>{p}</Chip>
                            ))}
                          </div>
                        </div>
                        <input
                          type="text"
                          maxLength={200}
                          placeholder="Anything specific? e.g. Indian family on a balcony, casual clothing"
                          value={peopleNote}
                          onChange={(e) => setPeopleNote(e.target.value)}
                        />
                        {(styleReferences.some((s) => ['Flat lay top-down', 'Studio product photography', 'Architectural / geometric', 'Bold graphic / typographic'].includes(s)) || /\b(people|person|human|faces?)\b/i.test(mustAvoid)) && (
                          <p className="hint" style={{ margin: 0, color: '#8A5A00' }}>
                            Heads up: a style you picked or your "must avoid" note usually means no people. People will still be added, so you may want to adjust those.
                          </p>
                        )}
                      </div>
                    )}
                  </FieldWithSuggest>

                  <Field label="Brand style from past assets" hint="Off by default - this brief only uses the styling you pick above. Turn on to also blend in the mood and imagery style AUTOMATr analyzed from your earlier brand assets.">
                    <div className="chip-row">
                      <Chip selected={!useBrandStyle} onClick={() => setUseBrandStyle(false)}>Only what I pick (default)</Chip>
                      <Chip selected={useBrandStyle} onClick={() => setUseBrandStyle(true)}>Also use my brand's analyzed style</Chip>
                    </div>
                  </Field>

                  <div className="nc-field-head" style={{ marginBottom: 6 }}>
                    <label style={{ margin: 0 }}>Lighting and composition</label>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                      <CostTag estimate={costs?.suggestion} />
                      <SuggestLink onClick={() => suggestSection('look')} loading={suggestBusy === 'look'} />
                    </span>
                  </div>
                  {suggestErr.section === 'look' && <AiErrorNotice error={suggestErr.error} />}
                  {suggestNote.section === 'look' && suggestNote.text && !suggestErr.error && <p className="hint" style={{ color: 'var(--blue-dark)' }}>{suggestNote.text}</p>}
                  <div className="grid-2">
                    <Field label="Lighting">
                      <select value={lightingStyle} onChange={(e) => setLightingStyle(e.target.value)}>
                        <option value="">No preference</option>
                        {LIGHTING_STYLES.map((l) => <option key={l}>{l}</option>)}
                      </select>
                    </Field>
                    <Field label="Composition">
                      <select value={compositionStyle} onChange={(e) => setCompositionStyle(e.target.value)}>
                        <option value="">No preference</option>
                        {COMPOSITION_STYLES.map((c) => <option key={c}>{c}</option>)}
                      </select>
                    </Field>
                  </div>
                </>
              )}

              {step.key === 'message' && (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, marginBottom: 16 }}>
                    <p className="hint" style={{ margin: 0, flex: 1 }}>
                      Fill these in by hand, or let AUTOMATr suggest a message and constraints from your brief so far.
                    </p>
                    <SuggestLink onClick={handleSuggestMessage} loading={suggestingMessage} />
                    <CostTag estimate={costs?.suggestion} />
                  </div>

                  <AiErrorNotice error={messageSuggestionError} />
                  {messageSuggestionRationale && !messageSuggestionError && (
                    <p className="hint" style={{ color: 'var(--blue-dark)', marginBottom: 14 }}>
                      {messageSuggestionRationale}
                    </p>
                  )}

                  <Field label="Primary message" hint="The single thing this creative should communicate at a glance.">
                    <input
                      type="text"
                      placeholder="e.g. This bag goes from desk to weekend trip"
                      value={primaryMessage}
                      onChange={(e) => setPrimaryMessage(e.target.value)}
                    />
                  </Field>

                  <div className="grid-2">
                    <Field label="Must include" hint="Optional.">
                      <input type="text" placeholder="e.g. the product bottle, our mascot" value={mustInclude} onChange={(e) => setMustInclude(e.target.value)} />
                    </Field>
                    <Field label="Must avoid" hint="Optional.">
                      <input type="text" placeholder="e.g. people's faces, competitor colors" value={mustAvoid} onChange={(e) => setMustAvoid(e.target.value)} />
                    </Field>
                  </div>
                </>
              )}

              {step.key === 'sources' && (
                <Field label="Reference creatives" hint="Optional - a competitor ad for style inspiration, or a specific graphic that should appear in the final design.">
                  {stagedReferences.length > 0 && (
                    <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 16 }}>
                      {stagedReferences.map((ref, i) => (
                        <div key={i} style={{ textAlign: 'center', maxWidth: 132 }}>
                          <div style={{ position: 'relative', width: 120, height: 120, margin: '0 auto' }} title={ref.credit || undefined}>
                            <div
                              style={{
                                width: 120,
                                height: 120,
                                borderRadius: 10,
                                border: '1px solid var(--line)',
                                backgroundColor: 'var(--paper-2, #eef1f8)',
                                backgroundImage: `url(${ref.previewUrl})`,
                                backgroundSize: 'contain',
                                backgroundRepeat: 'no-repeat',
                                backgroundPosition: 'center'
                              }}
                            />
                            {ref.mode === 'include' && !ref.exact && (
                              <span className="reference-thumb-badge" title="Sent to the AI model as the real subject">✓</span>
                            )}
                            {ref.mode === 'template' && (
                              <span className="reference-thumb-badge" title="Sent to the AI model as the creative to preserve - only the copy/message changes">🖼</span>
                            )}
                            {ref.exact && (
                              <span className="reference-thumb-badge" title="Kept exact - never sent to the AI, pasted onto the finished image unmodified">🔒</span>
                            )}
                          </div>
                          <p className="hint" style={{ margin: '6px 0 0', textTransform: 'capitalize' }}>
                            {ref.exact ? 'Exact' : ref.mode === 'style' ? 'Style' : ref.mode === 'template' ? 'Template' : 'Include'}
                          </p>
                          <button type="button" className="link-btn" style={{ fontSize: 11 }} onClick={() => unstageReference(i)}>
                            Remove
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="chip-row" style={{ marginBottom: 12 }}>
                    <Chip selected={referenceMode === 'include'} onClick={() => setReferenceMode('include')}>Include in final design</Chip>
                    <Chip selected={referenceMode === 'exact'} onClick={() => setReferenceMode('exact')}>Include - keep exact (no AI edits)</Chip>
                    <Chip selected={referenceMode === 'style'} onClick={() => setReferenceMode('style')}>Style reference only</Chip>
                    <Chip selected={referenceMode === 'template'} onClick={() => setReferenceMode('template')}>Use as template (keep logo/layout, update copy)</Chip>
                  </div>
                  <p className="hint" style={{ marginBottom: 14 }}>
                    {referenceMode === 'include'
                      ? 'Marked references are sent directly to the AI model as the real subject to depict - the AI may still redraw/adapt it into the scene, not just describe it.'
                      : referenceMode === 'exact'
                      ? "Marked references are never sent to the AI - they're pasted onto the finished design completely unmodified (good for exact logos/lockups/legal text)."
                      : referenceMode === 'template'
                      ? "Marked references are treated as a finished creative to preserve - the AI keeps its logo, layout, and branding as close to the original as possible, and only adapts the message/copy to the new brief."
                      : 'Marked references guide mood, palette, and treatment only - the AI will not copy their literal subject.'}
                  </p>
                  <div className="btn-row" style={{ marginTop: 0 }}>
                    <Btn variant="secondary" onClick={() => referenceFileInputRef.current?.click()}>
                      + Add reference creative
                    </Btn>
                    {stockConfigured && (
                      <Btn variant="secondary" onClick={() => setShowStockSearch((v) => !v)}>
                        {showStockSearch ? 'Hide stock photo search' : '🔍 Search stock photos'}
                      </Btn>
                    )}
                  </div>

                  {showStockSearch && (
                    <div style={{ marginTop: 16, padding: 14, border: '1px solid var(--line)', borderRadius: 10 }}>
                      <form onSubmit={handleStockSearch} className="select-row" style={{ marginBottom: 12 }}>
                        <input
                          type="text"
                          placeholder="e.g. coffee shop morning light"
                          value={stockQuery}
                          onChange={(e) => setStockQuery(e.target.value)}
                          style={{ flex: 1 }}
                        />
                        <Btn type="submit" variant="secondary" loading={stockSearching}>Search</Btn>
                      </form>

                      <ErrorText>{stockError}</ErrorText>

                      {stockResults.length > 0 && (
                        <>
                          <p className="hint" style={{ marginBottom: 10 }}>
                            Free stock photos via Pexels. Added as a &quot;{referenceMode === 'include' ? 'Include in final design' : referenceMode === 'exact' ? 'Include - keep exact' : referenceMode === 'template' ? 'Use as template' : 'Style reference only'}&quot;
                            reference - change that toggle above before adding if you want a different mode.
                          </p>
                          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                            {stockResults.map((photo, i) => (
                              <div
                                key={photo.id}
                                role="button"
                                tabIndex={0}
                                onClick={() => openStockLightbox(i)}
                                onKeyDown={(e) => e.key === 'Enter' && openStockLightbox(i)}
                                title={`Photo by ${photo.photographer}`}
                                style={{
                                  position: 'relative',
                                  width: 72,
                                  height: 72,
                                  padding: 0,
                                  border: '1px solid var(--line)',
                                  borderRadius: 8,
                                  overflow: 'hidden',
                                  cursor: 'zoom-in',
                                  backgroundImage: `url(${photo.previewUrl})`,
                                  backgroundSize: 'cover',
                                  backgroundPosition: 'center'
                                }}
                              >
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleAddStockPhoto(photo);
                                  }}
                                  disabled={addingStockId === photo.id}
                                  aria-label="Quick-add this photo"
                                  style={{
                                    position: 'absolute',
                                    inset: 0,
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    background: 'rgba(15,20,30,0.35)',
                                    color: '#fff',
                                    fontSize: 20,
                                    fontWeight: 600,
                                    border: 'none',
                                    padding: 0,
                                    cursor: addingStockId === photo.id ? 'default' : 'pointer',
                                    opacity: addingStockId === photo.id ? 1 : 0,
                                    transition: 'opacity .12s ease'
                                  }}
                                  onMouseEnter={(e) => { if (addingStockId !== photo.id) e.currentTarget.style.opacity = 1; }}
                                  onMouseLeave={(e) => { if (addingStockId !== photo.id) e.currentTarget.style.opacity = 0; }}
                                >
                                  {addingStockId === photo.id ? <span className="spinner" /> : '+'}
                                </button>
                              </div>
                            ))}
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </Field>
              )}

              {step.key === 'review' && (
                <div>
                  <p className="hint" style={{ marginBottom: 4 }}>Purpose</p>
                  <p style={{ marginBottom: 14 }}>{purpose}</p>

                  <p className="hint" style={{ marginBottom: 4 }}>Format</p>
                  <p style={{ marginBottom: 14 }}>
                    {mediums.length ? mediums.map((id) => `${getFormat(id).platform} ${getFormat(id).label}`).join(', ') : 'Instagram Feed (default)'}
                  </p>

                  {briefNote && (
                    <>
                      <p className="hint" style={{ marginBottom: 4 }}>Brief</p>
                      <p style={{ marginBottom: 14 }}>{briefNote}</p>
                    </>
                  )}

                  <p className="hint" style={{ marginBottom: 4 }}>Creative direction</p>
                  <p style={{ marginBottom: 14 }}>
                    {creativeDirectionCount > 0 ? `${creativeDirectionCount} choice${creativeDirectionCount === 1 ? '' : 's'} set` : 'Nothing set - AUTOMATr will use sensible defaults'}
                  </p>

                  {creativeType === 'adaptation' && originalHeadline && preservation.preservePrimaryHeadline === false && (
                    <>
                      <p className="hint" style={{ marginBottom: 4 }}>Headline</p>
                      <p style={{ marginBottom: 8 }}>
                        Original: <em>&quot;{originalHeadline}&quot;</em>
                      </p>
                      <p className="hint" style={{ marginBottom: 8 }}>
                        {selectedHeadline
                          ? 'Using the headline you picked below.'
                          : 'No headline picked - a new one will be written automatically from your brief and each copy direction. Generate variations below if you want to choose one yourself.'}
                      </p>
                      <AiErrorNotice error={headlineError} />
                      {headlineOptions.length === 0 && (
                        <Btn variant="secondary" loading={generatingHeadlines} onClick={handleGenerateHeadlineVariations}>
                          ✦ Generate headline variations
                        </Btn>
                      )}
                      {headlineOptions.length > 0 && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
                          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                            <input
                              type="radio"
                              name="headlineChoice"
                              checked={selectedHeadline === originalHeadline}
                              onChange={() => setSelectedHeadline(originalHeadline)}
                            />
                            Keep original: &quot;{originalHeadline}&quot;
                          </label>
                          {headlineOptions.map((option, i) => (
                            <label key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                              <input
                                type="radio"
                                name="headlineChoice"
                                checked={selectedHeadline === option}
                                onChange={() => setSelectedHeadline(option)}
                              />
                              &quot;{option}&quot;
                            </label>
                          ))}
                          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                            <input
                              type="radio"
                              name="headlineChoice"
                              checked={Boolean(customHeadline) && selectedHeadline === customHeadline}
                              onChange={() => setSelectedHeadline(customHeadline)}
                            />
                            <input
                              type="text"
                              placeholder="Write your own..."
                              value={customHeadline}
                              onChange={(e) => {
                                setCustomHeadline(e.target.value);
                                setSelectedHeadline(e.target.value);
                              }}
                              style={{ flex: 1 }}
                            />
                          </label>
                          <button type="button" className="link-btn" style={{ fontSize: 12, alignSelf: 'flex-start', marginTop: 4 }} onClick={handleGenerateHeadlineVariations}>
                            ↻ Regenerate options
                          </button>
                        </div>
                      )}
                    </>
                  )}

                  <p className="hint" style={{ marginBottom: 4 }}>Brand assets</p>
                  <p style={{ marginBottom: 20 }}>
                    {selectedAssets.size > 0 ? `${selectedAssets.size} selected` : 'None selected'}
                  </p>

                  <div className="btn-row" style={{ flexWrap: 'wrap', marginTop: 0 }}>
                    <Btn variant="primary" loading={loading} onClick={() => handleGenerate()}>
                      {hasExistingDesigns ? 'Save & continue' : 'Generate copy directions'}
                      <svg viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m0 0-5-5m5 5-5 5" /></svg>
                    </Btn>
                    {costs && !hasExistingDesigns && (
                      <CostTag estimate={costs.caption} />
                    )}
                    {hasExistingDesigns && (
                      <Btn variant="secondary" loading={loading} onClick={handleStartOver}>
                        ⟳ Start over (regenerate copy directions)
                      </Btn>
                    )}
                  </div>
                  {!hasExistingDesigns && (
                    <p className="hint" style={{ marginTop: 8 }}>
                      This drafts copy directions only - image generation is a separate, deliberate step once you've picked one to take to art.
                    </p>
                  )}
                  {hasExistingDesigns && (
                    <p className="hint" style={{ marginTop: 8 }}>
                      Your existing copy directions and images are preserved — "Save & continue" just updates the brief.
                      They only change if you use "Start over".
                    </p>
                  )}
                </div>
              )}
            </div>

            {!isLastStep && (
              <>
                <div className="btn-row wizard-actions" style={{ marginTop: 24 }}>
                  {!isFirstStep && <Btn variant="secondary" onClick={goBack}>← Back</Btn>}
                  <Btn variant="primary" onClick={goNext} disabled={step.key === 'basics' && mediums.length === 0}>Next →</Btn>
                  {step.key === 'basics' && mediums.length === 0 && <span className="hint" style={{ margin: 0 }}>Choose a platform and size to continue.</span>}
                </div>
                <div className="wizard-actions-spacer" />
              </>
            )}
            {isLastStep && !isFirstStep && (
              <>
                <div className="btn-row wizard-actions" style={{ marginTop: 24 }}>
                  <Btn variant="secondary" onClick={goBack}>← Back</Btn>
                </div>
                <div className="wizard-actions-spacer" />
              </>
            )}
          </Card>

          {creativeType !== 'adaptation' && (
            <Card>
              <CardHead title="Brand assets" tag={selectedAssets.size > 0 ? `${selectedAssets.size} selected` : undefined} />
              <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer', marginBottom: 12, padding: '10px 12px', border: '1px solid var(--line)', borderRadius: 10, background: 'var(--fog)' }}>
                <input type="checkbox" checked={followBrand} onChange={(e) => setFollowBrand(e.target.checked)} style={{ marginTop: 3 }} />
                <span>
                  <strong style={{ fontSize: 13.5 }}>Follow Brand's Design Language</strong>
                  <span className="hint" style={{ display: 'block', margin: '3px 0 0' }}>
                    {followBrand
                      ? 'On: uses your brand assets, colours, imagery style, mood and voice.'
                      : 'Off: clean slate - this creative ignores all brand guidelines and assets.'}
                  </span>
                </span>
              </label>
              <div style={followBrand ? undefined : { opacity: 0.45, pointerEvents: 'none' }}>
              <p className="hint" style={{ marginBottom: 14 }}>
                Stays visible while you work through the brief - select whichever logos/products should ground this creative.
              </p>
              <div className="asset-grid">
                {assets.length === 0 && <div className="empty-state">No brand assets yet - add some on Brand Assets.</div>}
                {assets.map((a) => (
                  <div
                    key={a._id}
                    className={`asset-tile ${selectedAssets.has(a._id) ? 'checked' : ''}`}
                    onClick={() => toggleAsset(a._id)}
                  >
                    <div
                      className="asset-tile__swatch"
                      style={a.mimeType?.startsWith('image/') ? { backgroundImage: `url(${resolveAssetUrl(a.url)})`, backgroundSize: 'cover' } : {}}
                    />
                    <p>{a.originalName}</p>
                    <span className="asset-tile__check" />
                    {selectedAssets.has(a._id) && (
                      <label
                        className="hint"
                        style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6, cursor: 'pointer' }}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <input
                          type="checkbox"
                          checked={exactAssets.has(a._id)}
                          onChange={(e) => toggleExactAsset(a._id, e)}
                        />
                        {a.kind === 'product' ? 'Lock product exactly (placed unchanged, centre)' : 'Keep exact (no AI edits)'}
                      </label>
                    )}
                  </div>
                ))}
              </div>
              </div>
            </Card>
          )}
        </div>

        <div>
          {creativeType === 'adaptation' ? null : (
            <Card>
              <CardHead title="Format preview" tag={getFormat(mediums[0]).label + ' (' + getFormat(mediums[0]).platform + ')'} />
              <div className="preview-frame">
                <div className={previewCanvasClass(mediums?.[0])} style={preview?.imageUrl ? { aspectRatio: previewAspectRatio(mediums?.[0]) } : { background: preview?.background || 'linear-gradient(160deg,#0F2A5C 0%,#2E5EFF 55%,#8FA9FF 100%)', aspectRatio: previewAspectRatio(mediums?.[0]) }}>
                  {preview?.imageUrl && <img className="cap-img" src={resolveAssetUrl(preview.imageUrl)} alt="" />}
                  <CaptionOverlay caption={preview?.caption} placeholder="Your generated caption will appear here." />
                </div>
                <div className="preview-meta"><span>{getFormat(mediums[0]).ratio}</span><span>Draft</span></div>
              </div>
              {preview?.textModel && <div className="model-row"><ModelPill>AI model</ModelPill></div>}
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
