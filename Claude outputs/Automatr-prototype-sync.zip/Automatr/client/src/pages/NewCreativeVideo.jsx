import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout.jsx';
import VideoFlowScreens from '../components/video/VideoFlowScreens.jsx';
import { useLeaveGuard } from '../components/LeaveGuard.jsx';
import { useWorkflow } from '../context/WorkflowContext.jsx';
import iconSparkle from '../assets/generate-home/sparkle.svg';

// New Creative, steps 5-7: Motion -> Video size -> Download video, for the creative picked on "Download image".
// The three screens are the shared video screens (also used by Convert to Video); this page only supplies the
// seven-step bar for the New Creative journey and sends the earlier steps back to the existing pages.
const STEPS = [['01', 'Purpose & brief'], ['02', 'Visual & style'], ['03', 'Messaging'], ['04', 'Download image'], ['05', 'Motion'], ['06', 'Video size'], ['07', 'Download video']];

export default function NewCreativeVideo() {
  const navigate = useNavigate();
  const { post, reset } = useWorkflow();
  const [step, setStep] = useState('motion');
  const selected = post?.designs?.find((d) => d.label === post.selectedVariantLabel);
  const imageUrl = selected?.imageUrl || '';
  useLeaveGuard(Boolean(post?._id));

  // Nothing to animate yet: go back to where the image is picked.
  useEffect(() => {
    if (!post?._id) navigate('/generate', { replace: true });
    else if (!imageUrl) navigate('/designs', { replace: true });
  }, [post?._id, imageUrl, navigate]);
  if (!post?._id || !imageUrl) return null;

  return (
    <Layout
      title={
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <button
            type="button"
            data-leave-guard
            onClick={() => { reset(); navigate('/generate', { state: { home: true } }); }}
            title="Start a new one"
            style={{ background: 'none', border: 'none', padding: 0, margin: 0, font: 'inherit', color: 'inherit', cursor: 'pointer', textDecoration: 'underline', textDecorationColor: 'var(--line)', textUnderlineOffset: 5 }}
          >
            Generate Media
          </button>
          <span aria-hidden="true" style={{ color: 'var(--muted)', fontWeight: 400 }}>&rsaquo;</span>
          <span style={{ color: 'var(--blue)' }}>New Creative</span>
        </span>
      }
    >
      <VideoFlowScreens
        postId={post._id}
        label={selected.label}
        imageUrl={imageUrl}
        step={step}
        onStep={setStep}
        stepBarProps={{
          icon: iconSparkle,
          name: 'New Creative',
          steps: STEPS,
          offset: 4,
          reachableBefore: [true, true, true, true],
          onStepBefore: (i) => navigate(i === 3 ? '/designs' : '/generate')
        }}
      />
    </Layout>
  );
}
