import React, { useMemo, useState } from 'react';
import GenerationAllowance from './GenerationAllowance.jsx';
import { resolveAssetUrl } from '../api/client.js';
import { getFormat } from '../constants/postFormats.js';

import hero1 from '../assets/generate-home/hero1.webp';
import hero2 from '../assets/generate-home/hero2.webp';
import hero3 from '../assets/generate-home/hero3.webp';
import hero4 from '../assets/generate-home/hero4.webp';
import finishUpImg from '../assets/generate-home/finish-up.webp';
import iconResize from '../assets/generate-home/resize.svg';
import iconSwap from '../assets/generate-home/replace.webp';
import iconText from '../assets/generate-home/text-select.svg';
import iconAdapt from '../assets/generate-home/creative-adapt.svg';
import iconConvert from '../assets/generate-home/icon-convert-video.svg';
import iconSparkle from '../assets/generate-home/sparkle.svg';
import iconClock from '../assets/generate-home/icon-clock.svg';
import iconArrow from '../assets/generate-home/arrow-right.svg';
import iconChevron from '../assets/generate-home/icon-chevron-right.svg';

/* ------------------------------------------------------------------ */
/* Active task (what the "Finish Up" card resumes)                      */
/* ------------------------------------------------------------------ */

// Same step sets the Stepper shows for each flow.
const STEP_SETS = {
  new: [['generate', 'Brief'], ['designs', 'Generate designs'], ['refine', 'Refine options'], ['modify', 'Modify post'], ['publish', 'Publish']],
  adaptation: [['generate', 'Brief'], ['designs', 'Generate designs'], ['publish', 'Publish']],
  resize: [['generate', 'Upload'], ['generate', 'Select size'], ['generate', 'Download']],
  hero: [['generate', 'Swap subject'], ['modify', 'Modify post'], ['publish', 'Publish']],
  headline: [['generate', 'Switch headline'], ['modify', 'Modify post'], ['publish', 'Publish']],
  convert: [['generate', 'Upload'], ['generate', 'Motion'], ['generate', 'Video size'], ['generate', 'Download video']]
};
const STEP_ROUTES = { generate: '/generate', designs: '/designs', refine: '/refine', modify: '/modify', publish: '/publish' };

export const FLOW_NAMES = {
  new: 'New Creative',
  adaptation: 'Creative Adaptation',
  resize: 'Size Adapt',
  hero: 'Subject Swap',
  headline: 'Headline Switch',
  convert: 'Convert to Video'
};

function selectedDesign(post) {
  return post?.designs?.find((d) => d.label === post.selectedVariantLabel);
}

/**
 * The one task the person can pick back up, or null.
 *  - a saved post that is not published yet -> resumes at the furthest step it has reached
 *  - otherwise a New Creative / Creative Adaptation brief that is open but not saved yet -> resumes the brief on /generate
 */
export function getActiveTask({ post, creativeType, stepIndex = 0, customNames = {} }) {
  const type = post?._id && post.creativeType ? post.creativeType : creativeType;
  if (!type) return null;
  if (post?._id && post.status === 'published') return null;

  const custom = typeof type === 'string' && type.startsWith('custom:');
  const name = custom ? customNames[type.slice(7)] || 'Custom creative' : FLOW_NAMES[type] || 'Creative';
  const steps = STEP_SETS[type];

  if (post?._id && steps) {
    const sel = selectedDesign(post);
    const hasImage = Boolean(sel?.imageUrl || sel?.background);
    if (type === 'convert') {
      // Convert to Video lives entirely on /generate: Upload -> Motion -> Video size -> Download video.
      const idx = hasImage ? 1 : 0;
      return {
        type, name, saved: true, stepIndex: idx, stepCount: steps.length, stepLabel: steps[idx][1],
        route: '/generate', thumb: sel?.imageUrl ? resolveAssetUrl(sel.imageUrl) : '', detail: ''
      };
    }
    if (type === 'resize') {
      // Size Adapt lives entirely on /generate: Upload -> Select Size -> Download.
      const idx = !hasImage ? 0 : sel.formatVariants?.some((v) => v.imageUrl) ? 2 : 1;
      let fmt = '';
      try { const f = getFormat(post.mediums?.[0]); fmt = f ? `${f.platform} ${f.label}` : ''; } catch { /* unknown */ }
      return {
        type, name, saved: true, stepIndex: idx, stepCount: steps.length, stepLabel: steps[idx][1],
        route: '/generate', thumb: sel?.imageUrl ? resolveAssetUrl(sel.imageUrl) : '', detail: ''
      };
    }
    const key = type === 'new' ? (hasImage ? 'modify' : 'designs') : type === 'adaptation' ? (hasImage ? 'publish' : 'designs') : hasImage ? 'modify' : 'generate';
    const idx = Math.max(0, steps.findIndex((s) => s[0] === key));
    let format = '';
    try { const f = getFormat(post.mediums?.[0]); format = f ? `${f.platform} ${f.label}` : ''; } catch { /* unknown format id */ }
    return {
      type, name, saved: true,
      stepIndex: idx, stepCount: steps.length, stepLabel: steps[idx][1],
      route: STEP_ROUTES[key],
      thumb: sel?.imageUrl ? resolveAssetUrl(sel.imageUrl) : '',
      detail: [post.purpose, format].filter(Boolean).join(' · ')
    };
  }

  // A brief that was started but not saved as a post yet. (The quick-fix editors and custom features keep nothing
  // until they create a post, so there is nothing to resume for them.)
  if (type !== 'new' && type !== 'adaptation') return null;
  return {
    type, name, saved: false,
    stepIndex: 0, stepCount: steps.length,
    stepLabel: `Brief, step ${stepIndex + 1}`,
    route: '/generate', thumb: '', detail: ''
  };
}

/* ------------------------------------------------------------------ */
/* UI                                                                   */
/* ------------------------------------------------------------------ */

const HEROES = [hero1, hero2, hero3, hero4];

// A different hero on every visit, never the same one twice in a row.
function pickHero() {
  const key = 'automatr:lastHero';
  let last = -1;
  try { last = parseInt(localStorage.getItem(key), 10); } catch { /* storage blocked */ }
  const pool = HEROES.map((_, i) => i).filter((i) => i !== last);
  const pick = pool[Math.floor(Math.random() * pool.length)];
  try { localStorage.setItem(key, String(pick)); } catch { /* storage blocked */ }
  return HEROES[pick];
}

function Cta({ children, muted }) {
  return (
    <span className={`gh-cta ${muted ? 'gh-cta--muted' : ''}`.trim()}>
      <span>{children}</span>
      <img src={iconArrow} alt="" width="24" height="24" />
    </span>
  );
}

function ActionCard({ className = '', onActivate, disabled, label, children }) {
  return (
    <div
      role="button"
      tabIndex={disabled ? -1 : 0}
      aria-disabled={disabled || undefined}
      aria-label={label}
      className={`gh-card ${className} ${disabled ? 'is-disabled' : ''}`.trim()}
      onClick={() => !disabled && onActivate()}
      onKeyDown={(e) => {
        if (!disabled && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); onActivate(); }
      }}
    >
      {children}
    </div>
  );
}

const QUICK_FIXES = [
  { type: 'resize', icon: iconResize, title: 'Size Adapt', text: 'Adjust the size but keep the creative intact.', cta: 'Adapt now' },
  { type: 'hero', icon: iconSwap, title: 'Subject Swap', text: 'Swap the subject in the creative without changing the message.', cta: 'Swap now' },
  { type: 'headline', icon: iconText, title: 'Headline Switch', text: 'Switch up the headline and leave everything else as is.', cta: 'Switch now' },
  { type: 'adaptation', icon: iconAdapt, title: 'Creative Adaptation', text: 'Rework an approved creative for a new message, market or promotion.', cta: 'Start now' },
  { type: 'convert', icon: iconConvert, title: 'Convert to Video', text: 'Transform an image into a video in a simple 3 step process.', cta: 'Convert now' }
];

// "Made for You" and "Repeat Flow" are selectable but empty until they ship (same as the design).
const TABS = [
  { id: 'quick', label: 'Quick Fixes' },
  { id: 'made', label: 'Made for You' },
  { id: 'repeat', label: 'Repeat Flow' }
];

export default function GenerateHome({ activeTask, customFeatures = [], onStart, onResume }) {
  const [tab, setTab] = useState('quick');
  const hero = useMemo(pickHero, []);
  const task = activeTask;
  const pct = task ? Math.round(((task.stepIndex + 1) / task.stepCount) * 100) : 0;

  return (
    <div className="gh-wrap">
      <div className="gh-allowance"><GenerationAllowance /></div>
      <div className="gh">
        <div className="gh__features">
          {/* New Creative: the existing brief-to-publish flow, unchanged */}
          <ActionCard className={`gh-card--feature ${task ? '' : 'gh-card--solo'}`.trim()} onActivate={() => onStart('new')} label="New Creative, start here">
            <div className="gh-feature">
              <div className="gh-feature__text">
                <p className="gh-body">Start with a fresh idea</p>
                <div className="gh-feature__title">
                  <img src={iconSparkle} alt="" width="28" height="28" />
                  <h2>New Creative</h2>
                </div>
                <p className="gh-body">Automatr helps you whip up different copy ideas and lets you check out, compare, and tweak image options before you hit publish.</p>
                <Cta>Start here</Cta>
              </div>
              <div className="gh-feature__media"><div className="gh-feature__image"><img src={hero} alt="" /></div></div>
            </div>
          </ActionCard>

          {/* Finish Up: resumes the active task. Hidden when nothing is in progress (New Creative then stretches). */}
          {task && (
          <ActionCard
            className="gh-card--feature"
            disabled={!task}
            onActivate={() => onResume(task)}
            label={task ? `Continue ${task.name}` : 'Finish Up, nothing in progress'}
          >
            <div className="gh-feature">
              <div className="gh-feature__text">
                <p className="gh-body">Pick up right where you left</p>
                <div className="gh-feature__title">
                  <img src={iconClock} alt="" width="18" height="18" />
                  <h2>Finish Up</h2>
                </div>
                {task ? (
                  <>
                    <div className="gh-task">
                      <span className="gh-task__name">{task.name}</span>
                      <span className="gh-task__step">
                        {task.saved ? `Step ${task.stepIndex + 1} of ${task.stepCount} · ${task.stepLabel}` : task.stepLabel}
                      </span>
                      {task.detail && <span className="gh-task__detail">{task.detail}</span>}
                      {task.saved && (
                        <span className="gh-progress" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} aria-label="Task progress">
                          <span style={{ width: `${pct}%` }} />
                        </span>
                      )}
                    </div>
                    <Cta>Continue</Cta>
                  </>
                ) : (
                  <>
                    <p className="gh-body">Nothing in progress right now. Start a creative and it will wait for you here.</p>
                    <Cta muted>No active task</Cta>
                  </>
                )}
              </div>
              <div className="gh-feature__media">
                <div className="gh-feature__image">
                  <img src={task?.thumb || finishUpImg} alt="" />
                </div>
              </div>
            </div>
          </ActionCard>
          )}
        </div>

        <section className="gh-quick">
          <div className="gh-tabs" role="tablist" aria-label="Shortcuts">
            {TABS.map((t, i) => (
              <button
                key={t.id}
                type="button"
                role="tab"
                id={`gh-tab-${t.id}`}
                aria-selected={tab === t.id}
                aria-controls={`gh-panel-${t.id}`}
                tabIndex={tab === t.id ? 0 : -1}
                className="gh-tab"
                onClick={() => setTab(t.id)}
                onKeyDown={(e) => {
                  const n = e.key === 'ArrowRight' ? i + 1 : e.key === 'ArrowLeft' ? i - 1 : null;
                  if (n === null) return;
                  e.preventDefault();
                  const next = TABS[(n + TABS.length) % TABS.length];
                  setTab(next.id);
                  document.getElementById(`gh-tab-${next.id}`)?.focus();
                }}
              >
                <img src={iconChevron} alt="" width="5" height="8" />
                <span>{t.label}</span>
              </button>
            ))}
          </div>

          {tab !== 'quick' && (
            <div className="gh-panel" role="tabpanel" id={`gh-panel-${tab}`} aria-labelledby={`gh-tab-${tab}`}>
              <p className="gh-empty">Nothing here yet.</p>
            </div>
          )}
          <div className="gh-panel" role="tabpanel" id="gh-panel-quick" aria-labelledby="gh-tab-quick" hidden={tab !== 'quick'}>
            {QUICK_FIXES.map((q) => (
              <ActionCard key={q.type} className="gh-card--fix" onActivate={() => onStart(q.type)} label={`${q.title}, ${q.cta}`}>
                <div className="gh-fix">
                  <img className="gh-fix__icon" src={q.icon} alt="" />
                  <div className="gh-fix__text">
                    <h3>{q.title}</h3>
                    <p className="gh-body">{q.text}</p>
                  </div>
                </div>
                <Cta>{q.cta}</Cta>
              </ActionCard>
            ))}
            {customFeatures.map((cf) => (
              <ActionCard key={cf.id} className="gh-card--fix" onActivate={() => onStart(`custom:${cf.id}`)} label={cf.name}>
                <div className="gh-fix">
                  <span className="gh-fix__icon gh-fix__icon--glyph" aria-hidden="true">{cf.icon || '✨'}</span>
                  <div className="gh-fix__text">
                    <h3>{cf.name}</h3>
                    <p className="gh-body">{cf.description || 'A custom creative set up for your workspace.'}</p>
                  </div>
                </div>
                <Cta>Start now</Cta>
              </ActionCard>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
