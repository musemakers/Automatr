import React from 'react';
import AnalyzingIndicator from '../AnalyzingIndicator.jsx';
import { resolveAssetUrl } from '../../api/client.js';
import { sizeText, VIDEO_ERROR } from './videoUtils.js';
import iconEye from '../../assets/video/icon-eye.svg';
import iconDownTile from '../../assets/video/icon-download-tile.svg';
import iconDownWhite from '../../assets/video/icon-download-white.svg';

/**
 * Final screen: "Your video". One fixed heading; the line under it changes from the generating message to the
 * ready message. Preview + Download sit on the tile, plus a main Download button. Every failure shows the same
 * message with Try again.
 */
export default function VideoDone({ kicker, run, dims, sizeLabel, motionTitles, downloading, onDownload, onPreview, onRetry, onChangeMotion, extras }) {
  const ready = run.status === 'done' && run.job?.videoUrl;
  const working = run.status === 'starting' || run.status === 'running';
  const failed = run.status === 'failed';
  const url = ready ? resolveAssetUrl(run.job.videoUrl) : '';
  const ar = dims ? dims.w / dims.h : 1;

  return (
    <div className="sa-panel">
      <div className="sa-text">
        <p className="sa-kicker">{kicker}</p>
        <h2 className="sa-heading">Your video</h2>
        <p role="status">
          {working && 'Generating your video. This can take a few minutes, and you can leave this page: it will keep going.'}
          {ready && `Preview it or download it${dims ? ` at ${sizeText(dims)}` : ''}.`}
          {failed && 'Something went wrong while creating your video.'}
          {run.status === 'idle' && 'Choose the motion and size first, then generate your video.'}
        </p>
        <div className="vf-recap">
          {dims && <p>Size → {sizeLabel || sizeText(dims)}</p>}
          <p>Motion → {motionTitles.length ? motionTitles.join(', ') : 'subtle ambient motion'}</p>
        </div>
        <button type="button" className="sa-btn sa-btn--primary" disabled={!ready || downloading} onClick={onDownload}>
          <span>Download</span><img className="sa-icon-down" src={iconDownWhite} alt="" />
        </button>
        {failed && (
          <>
            <p className="vf-err" role="alert">{run.error || VIDEO_ERROR}</p>
            <button type="button" className="sa-btn sa-btn--white sa-btn--sm" onClick={onRetry}><span>Try again</span></button>
          </>
        )}
        <div className="sa-links">
          <button type="button" className="sa-link" onClick={onChangeMotion}>← Change motion or size</button>
        </div>
        {extras}
      </div>

      <div className="sa-tiles" style={{ gridTemplateColumns: 'minmax(0,1fr)' }}>
        <div className="sa-tile vf-tile">
          <p className="sa-tile__title">Your video</p>
          <div className={`vf-vid ${working ? 'fx-skel' : ''}`.trim()} style={{ '--ar': ar }}>
            {working && <div className="vf-vid__state"><AnalyzingIndicator label="Creating your video…" size={48} /></div>}
            {ready && (
              <>
                <video src={url} muted loop autoPlay playsInline aria-label="Your video" />
                <div className="sa-tile__actions">
                  <button type="button" className="sa-btn sa-btn--white sa-btn--tile" onClick={onPreview}><img src={iconEye} alt="" /><span>Preview</span></button>
                  <span className="sa-tile__right">
                    <button type="button" className="sa-btn sa-btn--primary sa-btn--tile" disabled={downloading} aria-label="Download video" onClick={onDownload}>
                      <img className="sa-icon-down" src={iconDownTile} alt="" />
                    </button>
                  </span>
                </div>
              </>
            )}
            {(failed || run.status === 'idle') && <div className="vf-vid__state"><span>{failed ? 'No video yet.' : 'Your video will show here.'}</span></div>}
          </div>
          {dims && <p className="sa-tile__size">{sizeText(dims)}</p>}
        </div>
      </div>
    </div>
  );
}
