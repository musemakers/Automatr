import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from './Layout.jsx';
import AnalyzingIndicator from './AnalyzingIndicator.jsx';
import { FlowStepBar, ImageStage, ResultTile, ChooseSizePanel, GenerationError, readImageDims, sizePxOf, sizeSummary } from './flow/FlowParts.jsx';
import NextStepCards from './flow/NextStepCards.jsx';
import { useLeaveGuard } from './LeaveGuard.jsx';
import { AiErrorNotice } from './ui.jsx';
import { useWorkflow } from '../context/WorkflowContext.jsx';
import { useLightbox } from '../context/LightboxContext.jsx';
import { postsApi, aiApi } from '../api/resources.js';
import { apiErrorInfo, resolveAssetUrl, downloadFile } from '../api/client.js';
import { describeBox } from '../utils/boxes.js';

import iconSwapTool from '../assets/generate-home/replace.webp';
import iconUpload from '../assets/size-adapt/icon-upload.svg';
import iconSwap from '../assets/size-adapt/icon-swap.svg';
import iconPlus from '../assets/size-adapt/icon-plus.svg';
import iconDownWhite from '../assets/size-adapt/icon-download-white.svg';
import iconArrowWhite from '../assets/size-adapt/icon-arrow-right-white.svg';
import iconSparkle from '../assets/generate-home/sparkle.svg';

// Subject Swap: Upload -> Review (find the subject, then say what replaces it) -> Choose size -> Download.
// The app outlines every subject it finds on the creative (the person can tick the ones to replace, rename or
// re-describe them, or draw a box around one that was missed), then asks what should replace each ticked
// subject (describe it, "something similar", or a reference photo). Only those subjects change; the text, logos,
// background and layout are left alone. See editHeroImage / editHeroItems in posts.controller.js.
// Four steps in the bar. Review covers two screens: find the subject (internal step 1) and the new subject (2).
const STEPS = [['01', 'Upload'], ['02', 'Review'], ['03', 'Choose size'], ['04', 'Download']];
const BAR_OF = [0, 1, 1, 2, 3]; // internal screen -> bar step
const SCREEN_OF = [0, 1, 3, 4]; // bar step -> internal screen
const MODES = [['describe', 'Describe it'], ['similar', 'Something similar'], ['upload', 'Use a reference image']];
const MODE_LABELS = { describe: 'Describe the new subject', similar: 'Anything to change? (optional)', upload: 'Reference image' };
const SCAN_MESSAGES = ['Looking at your image…', 'Finding the subjects…', 'Describing what we found…'];

export default function HeroEditor({ onBack }) {
  const navigate = useNavigate();
  const { post, setPost } = useWorkflow();
  const { open: openLightbox } = useLightbox();
  const fileInputRef = useRef(null);
  const refInputRef = useRef(null);
  const refTargetRef = useRef(null);
  const nextId = useRef(1);

  const [step, setStep] = useState(0);
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [uploadError, setUploadError] = useState('');
  const [scanning, setScanning] = useState(false);
  const [scanned, setScanned] = useState(false);
  const [scanMsg, setScanMsg] = useState(0);
  const [scanNote, setScanNote] = useState('');
  const [subjects, setSubjects] = useState([]); // [{ id, label, detail, position, background, box, selected, user }]
  const [activeId, setActiveId] = useState(null);
  const [drawing, setDrawing] = useState(false);
  const [briefs, setBriefs] = useState({}); // id -> { mode, description, direction }
  const [refs, setRefs] = useState({}); // id -> { file, url }
  const [ideas, setIdeas] = useState({}); // id -> { list, seen, loading, error }
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState(null); // { width, height } once a swap has been made
  const [recap, setRecap] = useState([]);
  const [error, setError] = useState(null);
  const [size, setSize] = useState(null); // { platform, formatId, w, h, label } from the size picker; null = keep original
  const [origDims, setOrigDims] = useState(null);
  const [costs, setCosts] = useState(null);
  const [downloading, setDownloading] = useState(false);
  // Re-used on retry so a failed edit never leaves duplicate posts behind.
  const [postId, setPostId] = useState(() => (post?.creativeType === 'hero' ? post._id : null));

  useEffect(() => { aiApi.getCostEstimates().then(setCosts).catch(() => setCosts(null)); }, []);
  useEffect(() => () => previewUrl && URL.revokeObjectURL(previewUrl), [previewUrl]);
  useEffect(() => () => Object.values(refs).forEach((r) => URL.revokeObjectURL(r.url)), []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!drawing) return undefined;
    const onKey = (e) => e.key === 'Escape' && setDrawing(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [drawing]);

  const picked = useMemo(() => subjects.filter((s) => s.selected), [subjects]);
  const briefOf = (id) => briefs[id] || { mode: 'describe', description: '', direction: '' };
  const itemReady = (s) => {
    const b = briefOf(s.id);
    if (b.mode === 'describe') return b.description.trim().length > 2;
    if (b.mode === 'upload') return Boolean(refs[s.id]);
    return true;
  };
  const missing = picked.filter((s) => !itemReady(s));
  const canGenerate = picked.length > 0 && missing.length === 0 && !generating;

  const selectedDesign = post?.designs?.find((d) => d.label === post.selectedVariantLabel) || post?.designs?.[0];
  const resultUrl = result && selectedDesign?.imageUrl ? resolveAssetUrl(selectedDesign.imageUrl) : '';
  const baseName = (file?.name || 'creative').replace(/\.[^.]+$/, '');
  const reachable = [true, Boolean(file), Boolean(file) && scanned && picked.length > 0, Boolean(result)];
  useLeaveGuard(Boolean(file) || step > 0);

  /* ---------------- 01 Upload ---------------- */
  function handleFile(e) {
    const f = e.target.files?.[0];
    if (e.target.value !== undefined) e.target.value = '';
    if (!f) return;
    if (!/^image\/(png|jpe?g|webp)$/.test(f.type)) { setUploadError('Please choose an image file (PNG, JPG or WebP).'); return; }
    setUploadError('');
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
    setSize(null); setOrigDims(null);
    readImageDims(f).then(setOrigDims);
    // A new image means a new scan and a fresh brief.
    setSubjects([]); setScanned(false); setScanNote(''); setActiveId(null); setDrawing(false);
    setBriefs({}); setRefs({}); setIdeas({}); setResult(null); setError(null);
  }

  /* ---------------- 02 Find subject ---------------- */
  useEffect(() => {
    if (step !== 1 || !file || scanned || scanning) return undefined;
    let cancelled = false;
    setScanning(true);
    setScanMsg(0);
    const tick = setInterval(() => setScanMsg((m) => Math.min(m + 1, SCAN_MESSAGES.length - 1)), 1500);
    aiApi.analyzeHero(file).then((res) => {
      if (cancelled) return;
      const list = res.detected && res.hero ? (res.hero.heroes?.length ? res.hero.heroes : [res.hero]) : [];
      if (!list.length) setScanNote(res.reason ? `We couldn't identify the subject automatically (${res.reason}).` : "We couldn't identify the subject automatically.");
      setSubjects(list.map((h, i) => ({ id: `s${nextId.current++}`, label: `Subject ${i + 1}`, detail: h.description || '', position: h.position || '', background: h.background || '', box: h.box || null, selected: true })));
    }).catch(() => {
      if (!cancelled) setScanNote("We couldn't read this image automatically.");
    }).finally(() => {
      clearInterval(tick);
      if (!cancelled) { setScanning(false); setScanned(true); }
    });
    return () => { cancelled = true; clearInterval(tick); setScanning(false); };
  }, [step, file, scanned]); // eslint-disable-line react-hooks/exhaustive-deps

  function patchSubject(id, patch) { setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s))); }
  function removeSubject(id) { setSubjects((prev) => prev.filter((s) => s.id !== id)); if (activeId === id) setActiveId(null); }
  function addDrawn(box) {
    const id = `u${nextId.current++}`;
    setSubjects((prev) => [...prev, { id, label: `Subject ${prev.length + 1}`, detail: '', position: describeBox(box), background: '', box, selected: true, user: true }]);
    setActiveId(id);
    setDrawing(false);
  }

  /* ---------------- 03 New subject ---------------- */
  function patchBrief(id, patch) { setBriefs((prev) => ({ ...prev, [id]: { ...briefOf(id), ...(prev[id] || {}), ...patch } })); }

  function chooseRef(e) {
    const f = e.target.files?.[0];
    e.target.value = '';
    const id = refTargetRef.current;
    if (!f || !id) return;
    if (!/^image\//.test(f.type)) { setError({ message: 'Please choose an image file for the reference.' }); return; }
    setRefs((prev) => { if (prev[id]) URL.revokeObjectURL(prev[id].url); return { ...prev, [id]: { file: f, url: URL.createObjectURL(f) } }; });
  }

  async function suggest(s) {
    const cur = ideas[s.id] || { list: [], seen: [] };
    setIdeas((p) => ({ ...p, [s.id]: { ...cur, loading: true, error: null } }));
    try {
      const { ideas: fresh = [] } = await aiApi.heroIdeas({
        file, current: s.detail.trim() || s.label, position: describeBox(s.box) || s.position, background: s.background,
        direction: briefOf(s.id).direction, exclude: cur.seen
      });
      setIdeas((p) => ({ ...p, [s.id]: { list: fresh, seen: [...cur.seen, ...fresh], loading: false, error: null } }));
    } catch (err) {
      setIdeas((p) => ({ ...p, [s.id]: { ...cur, loading: false, error: apiErrorInfo(err) } }));
    }
  }

  /* ---------------- generate ---------------- */
  async function generate() {
    setError(null);
    setStep(4);
    setGenerating(true);
    setResult(null);
    const items = [];
    const files = [];
    picked.forEach((s) => {
      const b = briefOf(s.id);
      const it = { current: s.detail.trim() || s.label, position: describeBox(s.box) || s.position, mode: b.mode, newHero: b.mode === 'describe' ? b.description.trim() : '', direction: b.mode === 'similar' ? b.direction.trim() : '' };
      if (b.mode === 'upload') { it.refIndex = files.length; files.push(refs[s.id].file); it.newHero = b.description.trim(); }
      items.push(it);
    });
    setRecap(picked.map((s) => {
      const b = briefOf(s.id);
      return `${s.label} → ${b.mode === 'describe' ? `“${b.description.trim()}”` : b.mode === 'upload' ? 'your reference image' : `a fresh take${b.direction.trim() ? `: ${b.direction.trim()}` : ''}`}`;
    }).concat(`Size → ${sizeSummary(size, origDims)}`));
    try {
      let id = postId;
      if (!id) {
        const { post: created } = await postsApi.create({ creativeType: 'hero', purpose: 'Hero image edit', mediums: ['instagram_feed'], briefNote: '', selectedAssets: [], exactAssetIds: [], creativeBrief: {} });
        id = created._id;
        setPostId(id);
      }
      const keep = subjects.filter((s) => !s.selected).map((s) => `${s.detail.trim() || s.label}${s.box ? ` (${describeBox(s.box)})` : ''}`);
      const { post: updated, meta } = await postsApi.editHero(id, file, files, { items, keep }, sizePxOf(size));
      setPost(updated);
      setResult({ width: meta?.width, height: meta?.height });
      window.dispatchEvent(new Event('automatr:allowance-refresh'));
    } catch (err) {
      setError(apiErrorInfo(err));
    } finally {
      setGenerating(false);
    }
  }

  async function download() {
    if (!selectedDesign?.imageUrl) return;
    setDownloading(true);
    try {
      const ext = (/\.(png|jpe?g|webp)(\?|$)/i.exec(selectedDesign.imageUrl)?.[1] || 'png').toLowerCase();
      await downloadFile(resolveAssetUrl(selectedDesign.imageUrl), `${baseName}-subject-swap.${ext}`);
    } catch {
      setError({ message: 'Could not download the image. Try opening it in a new tab and saving it from there instead.' });
    } finally {
      setDownloading(false);
    }
  }

  const stageBoxes = subjects.map((s) => ({ id: s.id, box: s.box, selected: s.selected, label: `${s.label}: ${s.detail || 'drawn by you'}` }));

  return (
    <Layout
      title={
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <button type="button" onClick={onBack} title="Back to Generate Media"
            data-leave-guard style={{ background: 'none', border: 'none', padding: 0, margin: 0, font: 'inherit', color: 'inherit', cursor: 'pointer', textDecoration: 'underline', textDecorationColor: 'var(--line)', textUnderlineOffset: 5 }}>
            Generate Media
          </button>
          <span aria-hidden="true" style={{ color: 'var(--muted)', fontWeight: 400 }}>&rsaquo;</span>
          <span style={{ color: 'var(--blue)' }}>Subject Swap</span>
        </span>
      }
    >
      <input ref={fileInputRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={handleFile} />
      <input ref={refInputRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={chooseRef} />

      <FlowStepBar icon={iconSwapTool} name="Subject Swap" steps={STEPS} step={BAR_OF[step]} reachable={reachable} onStep={(i) => setStep(SCREEN_OF[i])} />
      {!(step === 4 && error && !resultUrl && !generating) && <AiErrorNotice error={error} />}

      {/* ---------------- 01 Upload ---------------- */}
      {step === 0 && (
        <div className="sa-panel">
          <div className="sa-text">
            <p className="sa-kicker">01 / Upload</p>
            <h2 className="sa-heading">Swap a subject</h2>
            <p>Upload a creative you are happy with, but where the person, product or hero image needs to change.</p>
            <p>We find the subject for you. Only that changes - the text, logos, background and layout stay exactly as they are.</p>
          </div>
          <div
            className="sa-drop"
            onDragOver={(e) => { e.preventDefault(); e.currentTarget.classList.add('is-dragover'); }}
            onDragLeave={(e) => e.currentTarget.classList.remove('is-dragover')}
            onDrop={(e) => { e.preventDefault(); e.currentTarget.classList.remove('is-dragover'); const f = e.dataTransfer?.files?.[0]; if (f) handleFile({ target: { files: [f] } }); }}
          >
            <div className="sa-drop__head">
              <p>{file ? 'Let’s find the subject' : 'Click upload to select a file (PNG, JPG or WebP).'}</p>
              {!file && <button type="button" className="sa-btn sa-btn--primary" onClick={() => fileInputRef.current?.click()}><span>Upload</span><img src={iconUpload} alt="" /></button>}
              {file && <button type="button" className="sa-btn sa-btn--primary" onClick={() => setStep(1)}><span>Find subject</span><img src={iconArrowWhite} alt="" /></button>}
            </div>
            {uploadError && <p className="fx-err" role="alert" style={{ marginBottom: 12 }}>{uploadError}</p>}
            <div className={`sa-preview ${previewUrl ? 'sa-preview--filled' : 'sa-preview--empty'}`.trim()}>
              {previewUrl && <img src={previewUrl} alt="Your uploaded creative" />}
              {previewUrl && (
                <button type="button" className="sa-btn sa-btn--white sa-btn--sm sa-preview__action" onClick={() => fileInputRef.current?.click()}>
                  <span>Reupload</span><img className="sa-icon-swap" src={iconSwap} alt="" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- 02 Find subject ---------------- */}
      {step === 1 && file && (
        <div className="sa-panel">
          <div className="sa-text">
            <p className="sa-kicker">02 / Find subject</p>
            <h2 className="sa-heading">Is this the subject?</h2>
            <p>The subjects in your creative have been spotted and described! Tick the ones you want to replace, fix any description we got wrong, or draw a box around something we missed.</p>
            {scanning && <div className="fx-list" aria-hidden="true"><div className="fx-skel fx-skel-row" /><div className="fx-skel fx-skel-row" /></div>}
            {!scanning && (
              <div className="fx-list">
                {subjects.map((s, i) => (
                  <div key={s.id} className={`fx-item ${s.id === activeId ? 'is-active' : ''} ${s.selected ? '' : 'is-off'}`.trim()} onFocus={() => setActiveId(s.id)} onClick={(e) => { if (e.target === e.currentTarget) setActiveId(s.id); }}>
                    <label className="fx-check">
                      <input type="checkbox" checked={s.selected} aria-label={`Replace ${s.label}`} onChange={(e) => patchSubject(s.id, { selected: e.target.checked })} />
                      <span className="fx-check__box" />
                    </label>
                    <div className="fx-item__body">
                      <div className="fx-item__top">
                        <span className="fx-item__num">{String(i + 1).padStart(2, '0')}</span>
                        <input className="fx-field fx-field--bare" style={{ flex: 1, width: 'auto', minWidth: 0 }} type="text" maxLength={40} value={s.label} aria-label={`Subject ${i + 1} name`} onChange={(e) => patchSubject(s.id, { label: e.target.value })} />
                        <button type="button" className="fx-item__remove" aria-label={`Remove ${s.label}`} onClick={() => removeSubject(s.id)}>×</button>
                      </div>
                      <textarea className="fx-field fx-field--bare fx-field--detail" rows={2} maxLength={200} value={s.detail} placeholder={s.user ? 'Say what is inside the box, e.g. the model holding the bag' : ''} aria-label={`Description of ${s.label}`} onChange={(e) => patchSubject(s.id, { detail: e.target.value })} />
                    </div>
                  </div>
                ))}
                {!subjects.length && <p className="sa-note">{scanNote ? `${scanNote} ` : ''}No subjects yet - draw a box around the part of the image you want to replace.</p>}
              </div>
            )}
            {!scanning && subjects.length > 0 && !subjects.some((x) => x.box) && <p className="sa-note">We couldn’t outline these on the image automatically. Use “Draw a subject” to mark the area yourself.</p>}
            <button type="button" className={`sa-btn sa-btn--outline ${drawing ? 'is-on' : ''}`.trim()} disabled={scanning} onClick={() => setDrawing((d) => !d)}>
              <span>{drawing ? 'Cancel drawing' : 'Draw a subject'}</span><img src={iconPlus} alt="" />
            </button>
            {drawing && <p className="sa-note">Click and drag on the image to outline the subject. Press Esc to cancel.</p>}
          </div>
          <div className="sa-drop">
            <div className="sa-drop__head">
              <p aria-live="polite">{scanning ? 'Looking…' : picked.length === 0 ? 'Select at least one subject to replace.' : 'Time to swap with a new subject.'}</p>
              <button type="button" className="sa-btn sa-btn--primary" disabled={scanning || picked.length === 0} onClick={() => setStep(2)}>
                <span>Describe new subject</span><img src={iconArrowWhite} alt="" />
              </button>
            </div>
            <ImageStage src={previewUrl} alt="Your creative with the detected subjects outlined" boxes={stageBoxes} activeId={activeId} scanning={scanning} scanText={SCAN_MESSAGES[scanMsg]} drawing={drawing} onSelect={setActiveId} onDraw={addDrawn} />
          </div>
        </div>
      )}

      {/* ---------------- 03 New subject ---------------- */}
      {step === 2 && (
        <div className="sa-panel">
          <div className="sa-text">
            <p className="sa-kicker">03 / New subject</p>
            <h2 className="sa-heading">What goes in its place?</h2>
            <p>Tell us what should replace each subject. Everything else in the image is kept as it is.</p>
          </div>
          <div className="sa-drop">
            <div className="sa-drop__head">
              <p aria-live="polite">{canGenerate ? 'Next, choose the size you need.' : picked.length === 0 ? 'Pick a subject to replace first (step 02).' : `Tell us what should replace ${missing.length === 1 ? missing[0].label : `${missing.length} of the subjects`} to continue.`} </p>
              <button type="button" className="sa-btn sa-btn--primary" disabled={!canGenerate} onClick={() => setStep(3)}>
                <span>Choose size</span><img src={iconArrowWhite} alt="" />
              </button>
            </div>
            <div className="fx-listwrap">
              {picked.map((s) => {
                const b = briefOf(s.id);
                const idea = ideas[s.id] || { list: [], seen: [] };
                const ref = refs[s.id];
                return (
                  <div className="fx-pane" key={s.id}>
                    <div className="fx-pane__head">
                      <span className="fx-label">{MODE_LABELS[b.mode]}</span>
                      <span className="fx-summary">Replacing: {s.label}</span>
                    </div>
                    <div className="fx-pills" role="radiogroup" aria-label={`How to describe the new ${s.label}`}>
                      {MODES.map(([m, label], i) => (
                        <button
                          key={m} type="button" role="radio" aria-checked={b.mode === m} tabIndex={b.mode === m ? 0 : -1}
                          className={`fx-pill ${b.mode === m ? 'is-on' : ''}`.trim()}
                          onClick={() => patchBrief(s.id, { mode: m })}
                          onKeyDown={(e) => {
                            const d = ['ArrowRight', 'ArrowDown'].includes(e.key) ? 1 : ['ArrowLeft', 'ArrowUp'].includes(e.key) ? -1 : 0;
                            if (!d) return;
                            e.preventDefault();
                            const sib = e.currentTarget.parentElement.children[(i + d + MODES.length) % MODES.length];
                            sib.click(); sib.focus();
                          }}
                        >{label}</button>
                      ))}
                    </div>
                    <div className="fx-pane__body">
                      {b.mode === 'describe' && (
                        <>
                          <textarea className="fx-field" value={b.description} maxLength={300} placeholder="e.g. A family of four laughing on a picnic blanket, late afternoon light" aria-label={`New subject for ${s.label}`} onChange={(e) => patchBrief(s.id, { description: e.target.value })} />
                          <div className="fx-row">
                            <input className="fx-field" style={{ flex: 1, minWidth: 160, width: 'auto' }} type="text" maxLength={200} value={b.direction} placeholder="Optional: direction for ideas, e.g. festive, outdoors" onChange={(e) => patchBrief(s.id, { direction: e.target.value })} />
                            <button type="button" className="sa-btn sa-btn--white sa-btn--sm" disabled={idea.loading} onClick={() => suggest(s)}>
                              <img src={iconSparkle} alt="" className="sa-btn__sm" /><span>{idea.loading ? 'Thinking…' : idea.list.length ? 'More ideas' : 'Suggest ideas'}</span>
                            </button>
                          </div>
                          <AiErrorNotice error={idea.error} />
                          {idea.list.length > 0 && (
                            <div className="fx-ideas">
                              {idea.list.map((t) => <button key={t} type="button" className="fx-idea" onClick={() => patchBrief(s.id, { description: t })}>{t}</button>)}
                            </div>
                          )}
                        </>
                      )}
                      {b.mode === 'similar' && (
                        <>
                          <textarea className="fx-field" value={b.direction} maxLength={200} placeholder="e.g. same pose, but a younger person in a green jacket" aria-label={`Changes for the similar ${s.label}`} onChange={(e) => patchBrief(s.id, { direction: e.target.value })} />
                          <p className="sa-note">We’ll keep this subject similar to the original and generate a fresh take.</p>
                        </>
                      )}
                      {b.mode === 'upload' && (
                        <>
                          <div className="fx-refbox">{ref && <img src={ref.url} alt={`Reference for ${s.label}`} />}</div>
                          <div className="fx-row">
                            <button type="button" className="sa-btn sa-btn--white sa-btn--sm" onClick={() => { refTargetRef.current = s.id; refInputRef.current?.click(); }}>
                              <img src={iconUpload} alt="" /><span>{ref ? 'Choose another' : 'Upload reference'}</span>
                            </button>
                          </div>
                          <input className="fx-field" type="text" maxLength={300} value={b.description} placeholder="Optional: what is it? e.g. our new 500ml bottle" onChange={(e) => patchBrief(s.id, { description: e.target.value })} />
                          <p className="sa-note">It is placed where the old subject sits, and its details, packaging and labels are kept exactly as in your photo. A clear photo with a plain background works best.</p>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
              {!picked.length && <p className="sa-note">No subject selected yet - go back to step 02.</p>}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- 03 Choose size ---------------- */}
      {step === 3 && (
        <ChooseSizePanel
          kicker="03 / Choose size"
          intro="Pick the size the finished creative should be. It is cropped to fit, or keep the original size."
          previewUrl={previewUrl}
          size={size}
          onSize={setSize}
          originalDims={origDims}
          costs={costs}
          hint={`${picked.length} subject${picked.length === 1 ? '' : 's'} will be swapped.`}
          onGenerate={generate}
        />
      )}

      {/* ---------------- 04 Download ---------------- */}
      {step === 4 && (
        <>
          <div className="sa-panel">
            <div className="sa-text">
              <p className="sa-kicker">04 / Download</p>
              <h2 className="sa-heading">Your creative</h2>
              {error && !resultUrl && !generating
                ? <GenerationError error={error} onRetry={generate} />
                : <p>{generating ? 'Generating your creative. This can take a minute or two - everything else stays untouched.' : 'Your subject changes have been applied. Preview the result, then download it.'}</p>}
              <div className="fx-list">{recap.map((r) => <p className="fx-recap" key={r}>{r}</p>)}</div>
              <button type="button" className="sa-btn sa-btn--primary" disabled={!resultUrl || generating || downloading} onClick={download}>
                <span>Download</span><img className="sa-icon-down" src={iconDownWhite} alt="" />
              </button>
              <NextStepCards adapt imageUrl={resultUrl && !generating ? selectedDesign.imageUrl : ''} />
              <div className="sa-links">
                <button type="button" className="sa-link" onClick={() => setStep(2)}>← Change the new subject</button>
                {resultUrl && <button type="button" className="sa-link" onClick={() => navigate('/modify')}>Fine tune →</button>}
              </div>
            </div>
            <div className="fx-tile-wrap">
              <ResultTile
                title={generating ? 'Generating your creative…' : resultUrl ? 'Your creative' : 'Not completed'} url={resultUrl} alt="Your creative with the new subject" downloadName="the swapped creative"
                working={generating} downloading={downloading} onDownload={download}
                onPreview={() => openLightbox({ src: selectedDesign.imageUrl, title: 'Your creative', downloadName: `${baseName}-subject-swap.png` })}
              >
                {generating ? <AnalyzingIndicator label="Swapping…" size={48} /> : <span>{selectedDesign?.imageNote || 'Nothing was made.'}</span>}
              </ResultTile>
            </div>
          </div>
        </>
      )}
    </Layout>
  );
}
