import React from 'react';

/** The one AI link used across the app: always the word "Suggest" with the AI icon. */
export function AiIcon({ size = 14 }) {
  return (
    <svg className="ai-link__ico" viewBox="0 0 24 24" width={size} height={size} fill="currentColor" aria-hidden="true">
      <path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z" />
    </svg>
  );
}

export default function SuggestLink({ onClick, loading = false, disabled = false, label, className = '', ...rest }) {
  return (
    <button
      type="button"
      className={`ai-link ${className}`.trim()}
      onClick={onClick}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      aria-label={label || 'Suggest'}
      {...rest}
    >
      <AiIcon />
      <span>Suggest</span>
    </button>
  );
}
