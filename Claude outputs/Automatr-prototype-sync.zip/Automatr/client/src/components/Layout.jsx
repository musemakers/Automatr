import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Sidebar from './Sidebar.jsx';
import Topbar from './Topbar.jsx';
import Stepper from './Stepper.jsx';
import BottomNav from './BottomNav.jsx';
import { LeaveGuardHost } from './LeaveGuard.jsx';
import { useWorkflow } from '../context/WorkflowContext.jsx';

export default function Layout({ eyebrow, title, step, flow, onStep, reachable, children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { post, reset } = useWorkflow();

  // Close the drawer automatically on navigation (mobile).
  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  // On every step after the first, the title is the same breadcrumb as step 1
  // ("Generate Media > Creative Adaptation"); Generate Media starts a new session.
  const showCrumb = step && step !== 'generate' && post?.creativeType;
  const crumbTitle = showCrumb ? (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
      <button
        type="button"
        onClick={() => {
          reset();
          navigate('/generate');
        }}
        title="Start a new one"
        style={{ background: 'none', border: 'none', padding: 0, margin: 0, font: 'inherit', color: 'inherit', cursor: 'pointer', textDecoration: 'underline', textDecorationColor: 'var(--line)', textUnderlineOffset: 5 }}
      >
        Generate Media
      </button>
      <span aria-hidden="true" style={{ color: 'var(--muted)', fontWeight: 400 }}>&rsaquo;</span>
      <span style={{ color: 'var(--blue)' }}>{post.creativeType === 'adaptation' ? 'Creative Adaptation' : post.creativeType === 'headline' ? 'Headline Switch' : post.creativeType === 'hero' ? 'Subject Swap' : post.creativeType === 'resize' ? 'Size Adapt' : post.creativeType === 'convert' ? 'Convert to Video' : 'New Creative'}</span>
    </span>
  ) : null;

  return (
    <div className="app" style={{ display: 'flex' }}>
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div
        className={`sidebar-overlay ${sidebarOpen ? 'visible' : ''}`.trim()}
        onClick={() => setSidebarOpen(false)}
      />
      <main className="main">
        <Topbar eyebrow={showCrumb ? undefined : eyebrow} title={crumbTitle || title} onMenuClick={() => setSidebarOpen(true)} />
        {step ? <Stepper current={step} flow={flow} post={flow && flow !== 'new' ? { ...post, creativeType: flow } : post} onStep={onStep} reachable={reachable} /> : null}
        <section className="page active">{children}</section>
      </main>
      <BottomNav />
      <LeaveGuardHost />
    </div>
  );
}
