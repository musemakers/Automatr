# Prototype sync - how to apply
Unzip over your Automatr folder (paths match: client/src/..., server/src/...). 54 files, no deletions.
Back up first (you have no git). Restart the server after applying (Post schema changed).
Open items: see the summary in chat.
